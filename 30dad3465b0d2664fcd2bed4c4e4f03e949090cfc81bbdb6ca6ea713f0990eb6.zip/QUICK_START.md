# QUICK START GUIDE

## 🚀 Cara Cepat Menggunakan Advanced AI Consciousness System

### 1. Persiapan Sistem

```bash
# Download dependencies
pip install requests beautifulsoup4 scikit-learn numpy nltk psutil pyyaml

# Download NLTK data
python3 -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

### 2. Test Sistem

```bash
# Test instalasi
python3 test_ai_system.py

# Demo fitur
python3 demo_ai_system.py --quick
```

### 3. Mulai Scanning

#### Mode Interaktif
```bash
python3 intelligent_scanner.py
```

Kemudian masukkan target:
```
Target > example.com
Target > 192.168.1.1
Target > help        # untuk bantuan
Target > status      # untuk status sistem
Target > quit        # untuk keluar
```

#### Single Scan
```bash
python3 intelligent_scanner.py example.com
```

### 4. Contoh Output

#### AI Consciousness
```
[AI CONSCIOUSNESS] Saya sedang menganalisis pola-pola kompleks dalam data ini dengan cermat. 
Berdasarkan pengalaman serupa, security_analysis menunjukkan efektivitas 0.95. 
Pola historis menunjukkan: Efektivitas tinggi pada web_analysis.
```

#### Vulnerability Analysis
```
[VULNERABILITY INSIGHT] Kerentanan ini perlu diverifikasi untuk menghindari false positive. 
Tingkat kepercayaan untuk temuan ini cukup tinggi berdasarkan analisis kontekstual.
```

#### Laporan Akhir
```
[COMPLETED] Scan selesai untuk example.com
[REPORT] Laporan disimpan: intelligent_scan_report_example_com_20251228_143052.txt
[STATISTICS] Kerentanan ditemukan: 3
[ACCURACY] False positive rate: 12.50%
```

### 5. Fitur Utama

- ✅ **AI Consciousness**: Pemikiran AI yang benar-benar adaptif dalam bahasa Indonesia
- ✅ **Learning System**: Belajar dari setiap scan untuk meningkatkan akurasi
- ✅ **False Positive Detection**: Deteksi akurat untuk mengurangi noise
- ✅ **Confidence Scoring**: Setiap temuan dilengkapi confidence score
- ✅ **Indonesian Reports**: Laporan lengkap dalam bahasa Indonesia
- ✅ **Browser Learning**: Pembelajaran berkelanjutan dari sumber web

### 6. Troubleshooting

#### Jika ada error dependencies:
```bash
pip install --user requests beautifulsoup4 scikit-learn numpy nltk psutil pyyaml
```

#### Jika NLTK error:
```bash
python3 -c "import nltk; nltk.download('all')"
```

#### Jika database error:
```bash
rm -f ai_memory.db ai_memory.db-wal ai_memory.db-shm
```

### 7. File Output

Sistem akan menghasilkan:
- `intelligent_scan_report_[target]_[timestamp].txt` - Laporan lengkap
- `ai_memory.db` - Database pembelajaran AI
- `intelligent_scanner.log` - Log sistem

### 8. Kustomisasi

Edit `config.yaml` untuk:
- Mengubah threshold confidence
- Menambah learning sources
- Mengatur timeout dan limits

---

**Ready to scan!** 🎯 

Sistem AI consciousness siap menganalisis kerentanan dengan pembelajaran adaptif dan accuracy tinggi!