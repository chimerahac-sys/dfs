#!/usr/bin/env python3
"""
SYSTEM TEST AND VALIDATION
Testing untuk memastikan semua komponen AI consciousness berjalan dengan baik
"""

import sys
import os
import time
import unittest
import sqlite3
import tempfile
from pathlib import Path
from datetime import datetime
from unittest.mock import patch, MagicMock

# Import komponen sistem yang akan ditest
try:
    from advanced_ai_consciousness_system import (
        IntelligentMemorySystem,
        BrowserLearningAgent, 
        VulnerabilityAnalysisEngine,
        IndonesianAIConsciousness,
        MasterIntelligentSystem,
        LearningData,
        VulnerabilityAnalysis
    )
except ImportError as e:
    print(f"Error importing system components: {e}")
    sys.exit(1)

class TestIntelligentMemorySystem(unittest.TestCase):
    """Test cases untuk Intelligent Memory System"""
    
    def setUp(self):
        """Setup test environment"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.memory_system = IntelligentMemorySystem(self.temp_db.name)
        
    def tearDown(self):
        """Cleanup test environment"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    def test_database_initialization(self):
        """Test database initialization"""
        conn = sqlite3.connect(self.temp_db.name)
        cursor = conn.cursor()
        
        # Check if tables exist
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        expected_tables = ['learning_memory', 'vulnerability_knowledge', 'adaptive_patterns']
        for table in expected_tables:
            self.assertIn(table, tables, f"Table {table} not found")
        
        conn.close()
    
    def test_store_learning(self):
        """Test storing learning data"""
        learning_data = LearningData(
            timestamp=datetime.now(),
            context="test_context",
            input_data="test_input",
            output_result="test_output",
            effectiveness_score=0.85,
            pattern_signature="test_signature",
            learning_category="test_category"
        )
        
        # Store learning data
        self.memory_system.store_learning(learning_data)
        
        # Verify stored data
        experiences = self.memory_system.retrieve_similar_experiences("test_context", limit=1)
        self.assertEqual(len(experiences), 1)
        self.assertEqual(experiences[0].context, "test_context")
        self.assertEqual(experiences[0].effectiveness_score, 0.85)
    
    def test_retrieve_similar_experiences(self):
        """Test retrieving similar experiences"""
        # Store multiple learning data
        for i in range(5):
            learning_data = LearningData(
                timestamp=datetime.now(),
                context=f"test_context_{i}",
                input_data=f"test_input_{i}",
                output_result=f"test_output_{i}",
                effectiveness_score=0.8 + (i * 0.02),
                pattern_signature=f"signature_{i}",
                learning_category="test_category"
            )
            self.memory_system.store_learning(learning_data)
        
        # Retrieve experiences
        experiences = self.memory_system.retrieve_similar_experiences("test_context", limit=3)
        self.assertLessEqual(len(experiences), 3)
        
        # Check ordering (should be by effectiveness and timestamp)
        if len(experiences) > 1:
            self.assertGreaterEqual(experiences[0].effectiveness_score, experiences[1].effectiveness_score)

class TestVulnerabilityAnalysisEngine(unittest.TestCase):
    """Test cases untuk Vulnerability Analysis Engine"""
    
    def setUp(self):
        """Setup test environment"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.memory_system = IntelligentMemorySystem(self.temp_db.name)
        self.vuln_analyzer = VulnerabilityAnalysisEngine(self.memory_system)
    
    def tearDown(self):
        """Cleanup test environment"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    def test_sql_injection_detection(self):
        """Test SQL injection detection"""
        target_data = {
            'response_content': "mysql_fetch_array() expects parameter 1 to be resource",
            'headers': {"Server": "Apache/2.4.41"},
            'status_code': 500
        }
        
        analysis = self.vuln_analyzer.analyze_vulnerability(target_data)
        
        self.assertIsInstance(analysis, VulnerabilityAnalysis)
        self.assertGreater(analysis.confidence_score, 0.5)
        self.assertEqual(analysis.severity_level, 'HIGH')
    
    def test_false_positive_detection(self):
        """Test false positive detection"""
        target_data = {
            'response_content': "404 Not Found - The requested page could not be found",
            'headers': {"Server": "nginx/1.18.0"},
            'status_code': 404
        }
        
        analysis = self.vuln_analyzer.analyze_vulnerability(target_data)
        
        # Should have high false positive probability
        self.assertGreater(analysis.false_positive_probability, 0.5)
    
    def test_xss_detection(self):
        """Test XSS detection"""
        target_data = {
            'response_content': "<script>alert('xss')</script> reflected in response",
            'headers': {"Content-Type": "text/html"},
            'status_code': 200
        }
        
        analysis = self.vuln_analyzer.analyze_vulnerability(target_data)
        
        self.assertGreater(analysis.confidence_score, 0.6)
        self.assertIn(analysis.severity_level, ['MEDIUM', 'HIGH'])

class TestIndonesianAIConsciousness(unittest.TestCase):
    """Test cases untuk Indonesian AI Consciousness"""
    
    def setUp(self):
        """Setup test environment"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.memory_system = IntelligentMemorySystem(self.temp_db.name)
        self.browser_agent = BrowserLearningAgent(self.memory_system)
        self.ai_consciousness = IndonesianAIConsciousness(self.memory_system, self.browser_agent)
    
    def tearDown(self):
        """Cleanup test environment"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    def test_thought_generation(self):
        """Test AI thought generation"""
        context = "analisis_keamanan_web"
        data = {"type": "security_analysis", "complexity": "high"}
        
        thought = self.ai_consciousness.process_intelligent_thought(context, data)
        
        self.assertIsInstance(thought, str)
        self.assertGreater(len(thought), 50)  # Should be meaningful length
    
    def test_context_classification(self):
        """Test context classification"""
        test_contexts = [
            ("vulnerability assessment", "security_analysis"),
            ("network traffic analysis", "network_analysis"),
            ("web application testing", "web_analysis"),
            ("general system check", "general_analysis")
        ]
        
        for context, expected_type in test_contexts:
            classified_type = self.ai_consciousness._classify_context(context)
            self.assertEqual(classified_type, expected_type)
    
    def test_data_complexity_assessment(self):
        """Test data complexity assessment"""
        test_cases = [
            (None, "minimal"),
            ("short string", "low"),
            ("a" * 1500, "medium"),
            ({"key1": "value1", "key2": "value2"}, "medium"),
            (list(range(150)), "high")
        ]
        
        for data, expected_complexity in test_cases:
            complexity = self.ai_consciousness._assess_data_complexity(data)
            self.assertEqual(complexity, expected_complexity)

class TestBrowserLearningAgent(unittest.TestCase):
    """Test cases untuk Browser Learning Agent"""
    
    def setUp(self):
        """Setup test environment"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.memory_system = IntelligentMemorySystem(self.temp_db.name)
        self.browser_agent = BrowserLearningAgent(self.memory_system)
    
    def tearDown(self):
        """Cleanup test environment"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    @patch('requests.Session.get')
    def test_learn_from_url_success(self, mock_get):
        """Test successful learning from URL"""
        # Mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"<html><head><title>Test Page</title></head><body><h1>Security Test</h1><p>This is a test page about vulnerability testing.</p></body></html>"
        mock_response.elapsed.total_seconds.return_value = 1.5
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = self.browser_agent.learn_from_url("https://example.com", "security_learning")
        
        self.assertTrue(result['success'])
        self.assertIn('learned_patterns', result)
        self.assertIn('knowledge_gained', result)
    
    @patch('requests.Session.get')
    def test_learn_from_url_failure(self, mock_get):
        """Test learning from URL failure"""
        # Mock failed response
        mock_get.side_effect = Exception("Connection failed")
        
        result = self.browser_agent.learn_from_url("https://invalid-url.com", "security_learning")
        
        self.assertFalse(result['success'])
        self.assertIn('error', result)
    
    def test_knowledge_gain_calculation(self):
        """Test knowledge gain calculation"""
        content = {
            'title': 'Security Test Page',
            'headings': ['Security', 'Testing', 'Vulnerability'],
            'paragraphs': ['This is about security testing'] * 100,
            'links': [f'https://example.com/page{i}' for i in range(20)]
        }
        
        knowledge_gain = self.browser_agent._calculate_knowledge_gain(content)
        
        self.assertIsInstance(knowledge_gain, float)
        self.assertGreaterEqual(knowledge_gain, 0.0)
        self.assertLessEqual(knowledge_gain, 1.0)

class TestMasterIntelligentSystem(unittest.TestCase):
    """Integration tests untuk Master Intelligent System"""
    
    def setUp(self):
        """Setup test environment"""
        self.master_system = MasterIntelligentSystem()
    
    def tearDown(self):
        """Cleanup test environment"""
        try:
            self.master_system.shutdown_system()
        except:
            pass
    
    def test_system_initialization(self):
        """Test system initialization"""
        # Test jika komponen utama ter-inisialisasi
        self.assertIsNotNone(self.master_system.memory_system)
        self.assertIsNotNone(self.master_system.browser_agent)
        self.assertIsNotNone(self.master_system.vuln_analyzer)
        self.assertIsNotNone(self.master_system.ai_consciousness)
    
    @patch('requests.get')
    def test_basic_reconnaissance(self, mock_get):
        """Test basic reconnaissance functionality"""
        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"Server": "Apache/2.4.41", "Content-Type": "text/html"}
        mock_response.text = "<html><body>Test page</body></html>"
        mock_response.elapsed.total_seconds.return_value = 0.5
        mock_get.return_value = mock_response
        
        recon_data = self.master_system._perform_basic_reconnaissance("example.com")
        
        self.assertIn('target', recon_data)
        self.assertIn('endpoints', recon_data)
        self.assertIn('technologies', recon_data)
        self.assertEqual(recon_data['target'], "example.com")

def run_performance_test():
    """Performance test untuk sistem"""
    print("\n" + "="*60)
    print("PERFORMANCE TEST")
    print("="*60)
    
    # Test memory usage
    import psutil
    process = psutil.Process()
    initial_memory = process.memory_info().rss / 1024 / 1024  # MB
    
    print(f"Initial memory usage: {initial_memory:.2f} MB")
    
    # Initialize system
    start_time = time.time()
    master_system = MasterIntelligentSystem()
    init_time = time.time() - start_time
    
    current_memory = process.memory_info().rss / 1024 / 1024  # MB
    print(f"Memory after initialization: {current_memory:.2f} MB")
    print(f"Initialization time: {init_time:.2f} seconds")
    
    # Test AI consciousness performance
    start_time = time.time()
    for i in range(10):
        thought = master_system.ai_consciousness.process_intelligent_thought(
            f"performance_test_{i}",
            {"iteration": i, "test": "performance"}
        )
    consciousness_time = time.time() - start_time
    
    print(f"10 AI consciousness thoughts generated in: {consciousness_time:.2f} seconds")
    print(f"Average per thought: {consciousness_time/10:.3f} seconds")
    
    # Test memory system performance
    start_time = time.time()
    for i in range(100):
        learning_data = LearningData(
            timestamp=datetime.now(),
            context=f"perf_test_{i}",
            input_data=f"test_data_{i}",
            output_result=f"result_{i}",
            effectiveness_score=0.8,
            pattern_signature=f"sig_{i}",
            learning_category="performance_test"
        )
        master_system.memory_system.store_learning(learning_data)
    
    storage_time = time.time() - start_time
    print(f"100 learning entries stored in: {storage_time:.2f} seconds")
    
    # Test retrieval performance
    start_time = time.time()
    for i in range(50):
        experiences = master_system.memory_system.retrieve_similar_experiences("perf_test", limit=5)
    retrieval_time = time.time() - start_time
    
    print(f"50 retrieval operations completed in: {retrieval_time:.2f} seconds")
    
    final_memory = process.memory_info().rss / 1024 / 1024  # MB
    print(f"Final memory usage: {final_memory:.2f} MB")
    print(f"Memory growth: {final_memory - initial_memory:.2f} MB")
    
    # Cleanup
    master_system.shutdown_system()

def run_all_tests():
    """Run semua test cases"""
    print("ADVANCED AI CONSCIOUSNESS SYSTEM - TESTING SUITE")
    print("="*60)
    
    # Run unit tests
    test_loader = unittest.TestLoader()
    test_suite = unittest.TestSuite()
    
    # Add test classes
    test_classes = [
        TestIntelligentMemorySystem,
        TestVulnerabilityAnalysisEngine,
        TestIndonesianAIConsciousness,
        TestBrowserLearningAgent,
        TestMasterIntelligentSystem
    ]
    
    for test_class in test_classes:
        tests = test_loader.loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Performance test
    run_performance_test()
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.failures:
        print("\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    success_rate = (result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100
    print(f"\nSuccess Rate: {success_rate:.1f}%")
    
    if success_rate >= 90:
        print("✅ SISTEM READY FOR PRODUCTION!")
    elif success_rate >= 70:
        print("⚠️  SISTEM MOSTLY FUNCTIONAL - REVIEW FAILURES")
    else:
        print("❌ SISTEM NEEDS SIGNIFICANT FIXES")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    # Check dependencies
    try:
        import requests
        import sqlite3
        from bs4 import BeautifulSoup
        import numpy as np
        from sklearn import __version__
        import nltk
        import psutil
        import yaml
        print("✅ All dependencies available")
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Run: pip install -r requirements.txt")
        sys.exit(1)
    
    # Run tests
    success = run_all_tests()
    sys.exit(0 if success else 1)