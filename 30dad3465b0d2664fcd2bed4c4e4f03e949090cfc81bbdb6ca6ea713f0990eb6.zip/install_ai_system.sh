#!/bin/bash

# ======================================================================
# ADVANCED AI CONSCIOUSNESS SYSTEM - AUTO INSTALLER
# ======================================================================
# Script untuk menginstall dan mengkonfigurasi sistem AI consciousness
# dengan pembelajaran adaptif dan vulnerability scanning
# 
# Dikembangkan oleh: MiniMax Agent
# ======================================================================

set -e  # Exit on any error

# Colors untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Banner
print_banner() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                    ADVANCED AI CONSCIOUSNESS INSTALLER                      ║"
    echo "║                                                                              ║"
    echo "║  Setup otomatis untuk sistem AI dengan pembelajaran adaptif                 ║"
    echo "║  • Vulnerability scanning dengan accuracy tinggi                            ║"
    echo "║  • AI consciousness dalam bahasa Indonesia                                  ║"
    echo "║  • Browser learning dan continuous improvement                              ║"
    echo "║  • False positive detection yang akurat                                     ║"
    echo "║                                                                              ║"
    echo "║  Dikembangkan oleh: MiniMax Agent                                           ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Fungsi logging
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check Python installation
check_python() {
    log_info "Memeriksa instalasi Python..."
    
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        log_success "Python3 ditemukan: $PYTHON_VERSION"
        
        # Check minimum version (3.8+)
        PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
        PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)
        
        if [ "$PYTHON_MAJOR" -ge 3 ] && [ "$PYTHON_MINOR" -ge 8 ]; then
            log_success "Versi Python memenuhi syarat (minimum 3.8)"
        else
            log_error "Python versi 3.8+ diperlukan. Ditemukan: $PYTHON_VERSION"
            exit 1
        fi
    else
        log_error "Python3 tidak ditemukan. Silakan install Python3 terlebih dahulu."
        exit 1
    fi
}

# Check pip installation
check_pip() {
    log_info "Memeriksa pip..."
    
    if command -v pip3 &> /dev/null; then
        log_success "pip3 ditemukan"
    elif command -v pip &> /dev/null; then
        log_success "pip ditemukan"
    else
        log_error "pip tidak ditemukan. Menginstall pip..."
        python3 -m ensurepip --default-pip
        if [ $? -eq 0 ]; then
            log_success "pip berhasil diinstall"
        else
            log_error "Gagal menginstall pip"
            exit 1
        fi
    fi
}

# Install Python dependencies
install_dependencies() {
    log_info "Menginstall dependencies Python..."
    
    if [ -f "requirements.txt" ]; then
        log_info "Menginstall dari requirements.txt..."
        python3 -m pip install -r requirements.txt --user
        
        if [ $? -eq 0 ]; then
            log_success "Dependencies berhasil diinstall"
        else
            log_warning "Beberapa dependencies mungkin gagal diinstall"
            log_info "Mencoba install dependencies satu per satu..."
            
            # Install critical dependencies manually
            CRITICAL_DEPS=("requests" "beautifulsoup4" "scikit-learn" "numpy" "nltk" "psutil" "pyyaml")
            
            for dep in "${CRITICAL_DEPS[@]}"; do
                log_info "Installing $dep..."
                python3 -m pip install "$dep" --user
                if [ $? -eq 0 ]; then
                    log_success "$dep installed"
                else
                    log_warning "Gagal menginstall $dep"
                fi
            done
        fi
    else
        log_warning "requirements.txt tidak ditemukan. Menginstall dependencies critical..."
        
        CRITICAL_DEPS=("requests" "beautifulsoup4" "scikit-learn" "numpy" "nltk" "psutil" "pyyaml")
        
        for dep in "${CRITICAL_DEPS[@]}"; do
            log_info "Installing $dep..."
            python3 -m pip install "$dep" --user
        done
    fi
}

# Download NLTK data
setup_nltk() {
    log_info "Mengsetup NLTK data..."
    
    python3 -c "
import nltk
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
    print('NLTK data berhasil didownload')
except Exception as e:
    print(f'Warning: Gagal download NLTK data: {e}')
"
}

# Create necessary directories
create_directories() {
    log_info "Membuat direktori yang diperlukan..."
    
    DIRS=("logs" "reports" "data" "models")
    
    for dir in "${DIRS[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            log_success "Direktori $dir dibuat"
        else
            log_info "Direktori $dir sudah ada"
        fi
    done
}

# Set executable permissions
set_permissions() {
    log_info "Mengatur permissions..."
    
    SCRIPTS=("intelligent_scanner.py" "advanced_ai_consciousness_system.py")
    
    for script in "${SCRIPTS[@]}"; do
        if [ -f "$script" ]; then
            chmod +x "$script"
            log_success "Permission set untuk $script"
        else
            log_warning "$script tidak ditemukan"
        fi
    done
}

# Test installation
test_installation() {
    log_info "Testing instalasi..."
    
    python3 -c "
import sys
import requests
import sqlite3
from sklearn import __version__ as sklearn_version
from bs4 import BeautifulSoup
import numpy as np
import nltk
import psutil
import yaml

print(f'Python: {sys.version}')
print(f'Scikit-learn: {sklearn_version}')
print('Semua dependencies berhasil diimport')
print('Instalasi berhasil!')
"
    
    if [ $? -eq 0 ]; then
        log_success "Test instalasi berhasil"
        return 0
    else
        log_error "Test instalasi gagal"
        return 1
    fi
}

# Create launch script
create_launcher() {
    log_info "Membuat script launcher..."
    
    cat > launch_intelligent_scanner.sh << 'EOF'
#!/bin/bash

# Quick launcher untuk Intelligent AI Scanner
# Dibuat otomatis oleh installer

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Meluncurkan Intelligent AI Scanner..."
echo "Lokasi: $SCRIPT_DIR"
echo ""

# Check jika ada argument
if [ $# -eq 0 ]; then
    echo "Mode interaktif"
    python3 intelligent_scanner.py
else
    echo "Single scan: $1"
    python3 intelligent_scanner.py "$1"
fi
EOF

    chmod +x launch_intelligent_scanner.sh
    log_success "Launcher script dibuat: launch_intelligent_scanner.sh"
}

# Create configuration file
create_config() {
    log_info "Membuat file konfigurasi..."
    
    cat > config.yaml << 'EOF'
# Advanced AI Consciousness System Configuration
# Generated automatically by installer

ai_system:
  learning_enabled: true
  continuous_learning: true
  learning_sources:
    - "https://cve.mitre.org"
    - "https://nvd.nist.gov"
    - "https://owasp.org"
  
  consciousness:
    language: "indonesian"
    thought_generation: true
    context_awareness: true
    
  memory:
    database_path: "ai_memory.db"
    max_memory_entries: 10000
    cleanup_interval_hours: 24

vulnerability_analysis:
  confidence_threshold: 0.7
  false_positive_threshold: 0.3
  verification_required: true
  
  severity_levels:
    high: ["sql_injection", "directory_traversal", "remote_code_execution"]
    medium: ["xss", "csrf", "information_disclosure"]
    low: ["version_disclosure", "directory_listing"]

scanning:
  timeout_seconds: 30
  max_redirects: 5
  user_agent: "Intelligent-AI-Scanner/1.0"
  
  target_validation: true
  rate_limiting: true
  max_concurrent_scans: 3

reporting:
  format: "detailed"
  include_recommendations: true
  include_verification_steps: true
  language: "indonesian"
  
  output_directory: "reports"
  auto_generate: true

logging:
  level: "INFO"
  file: "logs/intelligent_scanner.log"
  max_size_mb: 100
  backup_count: 5
EOF

    log_success "File konfigurasi dibuat: config.yaml"
}

# Main installation function
main() {
    print_banner
    
    log_info "Memulai instalasi Advanced AI Consciousness System..."
    echo ""
    
    # Step 1: Check Python
    check_python
    echo ""
    
    # Step 2: Check pip
    check_pip
    echo ""
    
    # Step 3: Install dependencies
    install_dependencies
    echo ""
    
    # Step 4: Setup NLTK
    setup_nltk
    echo ""
    
    # Step 5: Create directories
    create_directories
    echo ""
    
    # Step 6: Set permissions
    set_permissions
    echo ""
    
    # Step 7: Test installation
    if test_installation; then
        echo ""
        
        # Step 8: Create launcher and config
        create_launcher
        create_config
        echo ""
        
        # Installation success
        echo -e "${GREEN}"
        echo "╔══════════════════════════════════════════════════════════════════════════════╗"
        echo "║                           INSTALASI BERHASIL!                               ║"
        echo "╚══════════════════════════════════════════════════════════════════════════════╝"
        echo -e "${NC}"
        echo ""
        echo -e "${WHITE}CARA PENGGUNAAN:${NC}"
        echo ""
        echo -e "${CYAN}1. Mode Interaktif:${NC}"
        echo "   ./launch_intelligent_scanner.sh"
        echo "   atau"
        echo "   python3 intelligent_scanner.py"
        echo ""
        echo -e "${CYAN}2. Single Scan:${NC}"
        echo "   ./launch_intelligent_scanner.sh example.com"
        echo "   atau"
        echo "   python3 intelligent_scanner.py example.com"
        echo ""
        echo -e "${YELLOW}FITUR UTAMA:${NC}"
        echo "• AI consciousness yang benar-benar learning"
        echo "• Analisis vulnerability dengan accuracy tinggi"
        echo "• Deteksi false positive yang akurat"
        echo "• Pembelajaran adaptif dari browser dan data"
        echo "• Laporan dalam bahasa Indonesia"
        echo "• Confidence scoring dan risk assessment"
        echo ""
        echo -e "${GREEN}System siap digunakan!${NC}"
        
    else
        log_error "Instalasi gagal. Periksa error di atas."
        exit 1
    fi
}

# Run main function
main "$@"