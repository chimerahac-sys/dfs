#!/usr/bin/env python3
"""
Multi-Agent AI Learning System
Sistem dengan multiple AI agents yang dapat saling belajar dan berkoordinasi
"""

import asyncio
import json
import sqlite3
import threading
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import uuid

@dataclass
class AgentMessage:
    """Pesan antar agent"""
    sender_id: str
    receiver_id: str
    message_type: str
    content: Dict[str, Any]
    timestamp: datetime
    message_id: str = None
    
    def __post_init__(self):
        if self.message_id is None:
            self.message_id = str(uuid.uuid4())

@dataclass
class SharedKnowledge:
    """Pengetahuan yang dibagi antar agent"""
    knowledge_id: str
    source_agent: str
    knowledge_type: str
    content: Dict[str, Any]
    confidence_score: float
    timestamp: datetime
    usage_count: int = 0
    
    def __post_init__(self):
        if self.knowledge_id is None:
            self.knowledge_id = str(uuid.uuid4())

class SharedLearningDatabase:
    """Database untuk shared learning antar semua AI agents"""
    
    def __init__(self, db_path: str = "shared_ai_knowledge.db"):
        self.db_path = db_path
        self.connection = None
        self._initialize_database()
    
    def _initialize_database(self):
        """Inisialisasi database untuk shared learning"""
        self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
        self.connection.execute("""
        CREATE TABLE IF NOT EXISTS shared_knowledge (
            knowledge_id TEXT PRIMARY KEY,
            source_agent TEXT,
            knowledge_type TEXT,
            content TEXT,
            confidence_score REAL,
            timestamp TEXT,
            usage_count INTEGER DEFAULT 0
        )
        """)
        
        self.connection.execute("""
        CREATE TABLE IF NOT EXISTS agent_messages (
            message_id TEXT PRIMARY KEY,
            sender_id TEXT,
            receiver_id TEXT,
            message_type TEXT,
            content TEXT,
            timestamp TEXT
        )
        """)
        
        self.connection.execute("""
        CREATE TABLE IF NOT EXISTS agent_performance (
            agent_id TEXT,
            task_type TEXT,
            performance_score REAL,
            timestamp TEXT,
            details TEXT
        )
        """)
        
        self.connection.commit()
    
    def store_knowledge(self, knowledge: SharedKnowledge):
        """Menyimpan pengetahuan yang dibagi"""
        self.connection.execute("""
        INSERT OR REPLACE INTO shared_knowledge 
        (knowledge_id, source_agent, knowledge_type, content, confidence_score, timestamp, usage_count)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            knowledge.knowledge_id,
            knowledge.source_agent,
            knowledge.knowledge_type,
            json.dumps(knowledge.content),
            knowledge.confidence_score,
            knowledge.timestamp.isoformat(),
            knowledge.usage_count
        ))
        self.connection.commit()
    
    def retrieve_knowledge(self, knowledge_type: str, limit: int = 10) -> List[SharedKnowledge]:
        """Mengambil pengetahuan berdasarkan tipe"""
        cursor = self.connection.execute("""
        SELECT * FROM shared_knowledge 
        WHERE knowledge_type = ? 
        ORDER BY confidence_score DESC, timestamp DESC 
        LIMIT ?
        """, (knowledge_type, limit))
        
        results = []
        for row in cursor.fetchall():
            knowledge = SharedKnowledge(
                knowledge_id=row[0],
                source_agent=row[1],
                knowledge_type=row[2],
                content=json.loads(row[3]),
                confidence_score=row[4],
                timestamp=datetime.fromisoformat(row[5]),
                usage_count=row[6]
            )
            results.append(knowledge)
        
        return results
    
    def store_message(self, message: AgentMessage):
        """Menyimpan pesan antar agent"""
        self.connection.execute("""
        INSERT INTO agent_messages 
        (message_id, sender_id, receiver_id, message_type, content, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            message.message_id,
            message.sender_id,
            message.receiver_id,
            message.message_type,
            json.dumps(message.content),
            message.timestamp.isoformat()
        ))
        self.connection.commit()
    
    def get_agent_messages(self, agent_id: str, limit: int = 50) -> List[AgentMessage]:
        """Mengambil pesan untuk agent tertentu"""
        cursor = self.connection.execute("""
        SELECT * FROM agent_messages 
        WHERE receiver_id = ? OR sender_id = ?
        ORDER BY timestamp DESC 
        LIMIT ?
        """, (agent_id, agent_id, limit))
        
        results = []
        for row in cursor.fetchall():
            message = AgentMessage(
                message_id=row[0],
                sender_id=row[1],
                receiver_id=row[2],
                message_type=row[3],
                content=json.loads(row[4]),
                timestamp=datetime.fromisoformat(row[5])
            )
            results.append(message)
        
        return results

class BaseAIAgent:
    """Base class untuk semua AI agents"""
    
    def __init__(self, agent_id: str, agent_type: str, shared_db: SharedLearningDatabase):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.shared_db = shared_db
        self.status = "INITIALIZED"
        self.message_queue = asyncio.Queue()
        self.learning_history = []
        self.specialized_knowledge = {}
        
    async def send_message(self, receiver_id: str, message_type: str, content: Dict[str, Any]):
        """Mengirim pesan ke agent lain"""
        message = AgentMessage(
            sender_id=self.agent_id,
            receiver_id=receiver_id,
            message_type=message_type,
            content=content,
            timestamp=datetime.now()
        )
        
        self.shared_db.store_message(message)
        await self.message_queue.put(message)
    
    async def receive_messages(self):
        """Menerima dan memproses pesan"""
        while True:
            try:
                message = await asyncio.wait_for(self.message_queue.get(), timeout=1.0)
                await self.process_message(message)
            except asyncio.TimeoutError:
                continue
    
    async def process_message(self, message: AgentMessage):
        """Memproses pesan yang diterima (override di subclass)"""
        print(f"[{self.agent_id}] Received message from {message.sender_id}: {message.message_type}")
    
    def learn_from_experience(self, experience: Dict[str, Any]):
        """Belajar dari pengalaman dan bagikan ke database shared"""
        knowledge = SharedKnowledge(
            knowledge_id=str(uuid.uuid4()),
            source_agent=self.agent_id,
            knowledge_type=self.agent_type,
            content=experience,
            confidence_score=experience.get('confidence', 0.5),
            timestamp=datetime.now()
        )
        
        self.shared_db.store_knowledge(knowledge)
        self.learning_history.append(knowledge)
        
        print(f"[{self.agent_id}] Learned new knowledge: {experience.get('summary', 'Unknown')}")
    
    def get_shared_knowledge(self, knowledge_type: str) -> List[SharedKnowledge]:
        """Mengambil pengetahuan dari agent lain"""
        return self.shared_db.retrieve_knowledge(knowledge_type)

class SecurityAIAgent(BaseAIAgent):
    """AI Agent khusus untuk security analysis"""
    
    def __init__(self, shared_db: SharedLearningDatabase):
        super().__init__("security_ai", "security_analysis", shared_db)
        self.vulnerability_patterns = {}
        self.false_positive_indicators = {}
    
    async def analyze_security_target(self, target: str) -> Dict[str, Any]:
        """Analisis keamanan target"""
        print(f"[Security AI] Menganalisis keamanan untuk: {target}")
        
        # Ambil pengetahuan dari agent lain
        web_knowledge = self.get_shared_knowledge("web_analysis")
        pattern_knowledge = self.get_shared_knowledge("pattern_recognition")
        
        # Simulasi analisis (dalam implementasi nyata, ini akan call real security tools)
        analysis_result = {
            "target": target,
            "vulnerabilities_found": [
                {"type": "SQL Injection", "confidence": 0.85, "location": "/login.php"},
                {"type": "XSS", "confidence": 0.73, "location": "/search.php"}
            ],
            "false_positive_probability": 0.15,
            "risk_score": 8.2,
            "recommendations": [
                "Implement input validation",
                "Use parameterized queries",
                "Enable WAF protection"
            ]
        }
        
        # Belajar dari hasil analisis
        self.learn_from_experience({
            "type": "security_scan",
            "target": target,
            "result": analysis_result,
            "confidence": 0.85,
            "summary": f"Security analysis completed for {target}"
        })
        
        return analysis_result

class WebLearningAIAgent(BaseAIAgent):
    """AI Agent untuk web learning dan data gathering"""
    
    def __init__(self, shared_db: SharedLearningDatabase):
        super().__init__("web_learning_ai", "web_analysis", shared_db)
        self.crawled_data = {}
        self.learning_sources = {}
    
    async def learn_from_web(self, url: str, topic: str) -> Dict[str, Any]:
        """Belajar dari website"""
        print(f"[Web Learning AI] Belajar dari: {url} tentang {topic}")
        
        # Simulasi web learning (dalam implementasi nyata, ini akan scrape website)
        learning_result = {
            "url": url,
            "topic": topic,
            "content_summary": f"Learned about {topic} from {url}",
            "key_points": [
                f"Important concept about {topic}",
                f"Best practices for {topic}",
                f"Common mistakes in {topic}"
            ],
            "knowledge_score": 0.78,
            "timestamp": datetime.now().isoformat()
        }
        
        # Belajar dan bagikan pengetahuan
        self.learn_from_experience({
            "type": "web_learning",
            "url": url,
            "topic": topic,
            "result": learning_result,
            "confidence": 0.78,
            "summary": f"Web learning completed for {topic}"
        })
        
        return learning_result

class PatternRecognitionAIAgent(BaseAIAgent):
    """AI Agent untuk pattern recognition dan analysis"""
    
    def __init__(self, shared_db: SharedLearningDatabase):
        super().__init__("pattern_ai", "pattern_recognition", shared_db)
        self.patterns = {}
        self.anomalies = {}
    
    async def analyze_patterns(self, data: Any) -> Dict[str, Any]:
        """Analisis pola dalam data"""
        print(f"[Pattern AI] Menganalisis pola dalam data...")
        
        # Simulasi pattern analysis
        pattern_result = {
            "patterns_detected": [
                {"pattern_type": "SQL injection attempts", "frequency": 15, "confidence": 0.89},
                {"pattern_type": "Port scanning activity", "frequency": 8, "confidence": 0.67}
            ],
            "anomalies": [
                {"anomaly_type": "Unusual traffic spike", "severity": "HIGH", "confidence": 0.94}
            ],
            "recommendations": [
                "Monitor SQL injection patterns",
                "Investigate traffic anomaly",
                "Update security rules"
            ]
        }
        
        # Belajar dari analisis pola
        self.learn_from_experience({
            "type": "pattern_analysis",
            "data_type": type(data).__name__,
            "result": pattern_result,
            "confidence": 0.82,
            "summary": "Pattern analysis completed"
        })
        
        return pattern_result

class CoordinationAIAgent(BaseAIAgent):
    """AI Agent untuk koordinasi dan orchestration"""
    
    def __init__(self, shared_db: SharedLearningDatabase):
        super().__init__("coordinator_ai", "coordination", shared_db)
        self.agents = {}
        self.task_queue = []
    
    async def coordinate_multi_agent_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Koordinasi task yang melibatkan multiple agents"""
        print(f"[Coordinator AI] Mengkoordinasi task: {task.get('type', 'Unknown')}")
        
        results = {}
        
        # Koordinasi dengan Security AI
        if 'security_analysis' in task.get('requirements', []):
            security_result = await self.request_analysis("security_ai", task)
            results['security'] = security_result
        
        # Koordinasi dengan Web Learning AI
        if 'web_learning' in task.get('requirements', []):
            web_result = await self.request_analysis("web_learning_ai", task)
            results['web_learning'] = web_result
        
        # Koordinasi dengan Pattern AI
        if 'pattern_analysis' in task.get('requirements', []):
            pattern_result = await self.request_analysis("pattern_ai", task)
            results['patterns'] = pattern_result
        
        # Gabungkan hasil dari semua agent
        final_result = {
            "task_id": task.get('id', str(uuid.uuid4())),
            "task_type": task.get('type'),
            "agent_results": results,
            "coordination_score": 0.88,
            "completion_status": "SUCCESS"
        }
        
        # Belajar dari koordinasi
        self.learn_from_experience({
            "type": "coordination",
            "task": task,
            "result": final_result,
            "confidence": 0.88,
            "summary": f"Multi-agent coordination completed for {task.get('type')}"
        })
        
        return final_result
    
    async def request_analysis(self, agent_id: str, task: Dict[str, Any]) -> Dict[str, Any]:
        """Request analisis dari agent tertentu"""
        # Simulasi komunikasi dengan agent lain
        return {
            "agent_id": agent_id,
            "task_completed": True,
            "result": f"Analysis completed by {agent_id}",
            "timestamp": datetime.now().isoformat()
        }

class MultiAgentAISystem:
    """Sistem Multi-Agent AI yang terintegrasi"""
    
    def __init__(self):
        self.shared_db = SharedLearningDatabase()
        self.agents = {}
        self.is_running = False
        
        # Inisialisasi semua AI agents
        self._initialize_agents()
    
    def _initialize_agents(self):
        """Inisialisasi semua AI agents"""
        self.agents = {
            'security_ai': SecurityAIAgent(self.shared_db),
            'web_learning_ai': WebLearningAIAgent(self.shared_db),
            'pattern_ai': PatternRecognitionAIAgent(self.shared_db),
            'coordinator_ai': CoordinationAIAgent(self.shared_db)
        }
        
        print("Multi-Agent AI System initialized with:")
        for agent_id, agent in self.agents.items():
            print(f"  - {agent_id}: {agent.agent_type}")
    
    def initialize_agents(self):
        """Public method untuk inisialisasi agents"""
        return self._initialize_agents()
    
    async def start_system(self):
        """Start multi-agent system"""
        self.is_running = True
        print("\n[SYSTEM] Starting Multi-Agent AI System...")
        
        # Start semua agents
        tasks = []
        for agent in self.agents.values():
            task = asyncio.create_task(agent.receive_messages())
            tasks.append(task)
        
        print("[SYSTEM] All agents are now active and ready for collaboration")
        return tasks
    
    async def execute_comprehensive_analysis(self, target: str) -> Dict[str, Any]:
        """Eksekusi analisis komprehensif dengan semua agents"""
        print(f"\n[SYSTEM] Starting comprehensive analysis for: {target}")
        
        # Task yang melibatkan semua agent
        task = {
            "id": str(uuid.uuid4()),
            "type": "comprehensive_security_analysis",
            "target": target,
            "requirements": ["security_analysis", "web_learning", "pattern_analysis"]
        }
        
        # Koordinasi melalui Coordinator AI
        coordinator = self.agents['coordinator_ai']
        result = await coordinator.coordinate_multi_agent_task(task)
        
        # Tambahkan hasil individual dari setiap agent
        security_ai = self.agents['security_ai']
        security_result = await security_ai.analyze_security_target(target)
        
        web_ai = self.agents['web_learning_ai']
        web_result = await web_ai.learn_from_web(f"https://{target}", "security_best_practices")
        
        pattern_ai = self.agents['pattern_ai']
        pattern_result = await pattern_ai.analyze_patterns({"target": target, "data": "sample_data"})
        
        # Gabungkan semua hasil
        comprehensive_result = {
            "target": target,
            "analysis_timestamp": datetime.now().isoformat(),
            "coordination_result": result,
            "detailed_results": {
                "security_analysis": security_result,
                "web_learning": web_result,
                "pattern_analysis": pattern_result
            },
            "learning_summary": self._generate_learning_summary(),
            "system_status": "ANALYSIS_COMPLETE"
        }
        
        print(f"[SYSTEM] Comprehensive analysis completed for {target}")
        return comprehensive_result
    
    def _generate_learning_summary(self) -> Dict[str, Any]:
        """Generate ringkasan pembelajaran dari semua agent"""
        summary = {
            "total_knowledge_entries": 0,
            "agent_learning_counts": {},
            "recent_learnings": []
        }
        
        for agent_id, agent in self.agents.items():
            learning_count = len(agent.learning_history)
            summary["agent_learning_counts"][agent_id] = learning_count
            summary["total_knowledge_entries"] += learning_count
            
            # Ambil pembelajaran terbaru
            if agent.learning_history:
                latest = agent.learning_history[-1]
                summary["recent_learnings"].append({
                    "agent": agent_id,
                    "type": latest.knowledge_type,
                    "summary": latest.content.get('summary', 'No summary'),
                    "timestamp": latest.timestamp.isoformat()
                })
        
        return summary
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get status sistem multi-agent"""
        return {
            "system_status": "ACTIVE" if self.is_running else "INACTIVE",
            "agent_count": len(self.agents),
            "agents": {
                agent_id: {
                    "type": agent.agent_type,
                    "status": agent.status,
                    "learning_history_size": len(agent.learning_history)
                }
                for agent_id, agent in self.agents.items()
            },
            "shared_knowledge_available": True,
            "inter_agent_communication": "ENABLED"
        }

# Demo function untuk testing
async def demo_multi_agent_system():
    """Demo lengkap multi-agent system"""
    print("=" * 60)
    print("DEMO: Multi-Agent AI Learning System")
    print("=" * 60)
    
    # Inisialisasi sistem
    system = MultiAgentAISystem()
    
    # Start sistem
    await system.start_system()
    
    # Test comprehensive analysis
    target = "example.com"
    result = await system.execute_comprehensive_analysis(target)
    
    # Tampilkan hasil
    print("\n" + "=" * 60)
    print("HASIL ANALISIS KOMPREHENSIF")
    print("=" * 60)
    print(f"Target: {result['target']}")
    print(f"Status: {result['system_status']}")
    print(f"Timestamp: {result['analysis_timestamp']}")
    
    print("\nRingkasan Pembelajaran:")
    learning = result['learning_summary']
    print(f"  Total pengetahuan: {learning['total_knowledge_entries']}")
    print(f"  Pembelajaran per agent:")
    for agent_id, count in learning['agent_learning_counts'].items():
        print(f"    - {agent_id}: {count} pembelajaran")
    
    print("\nStatus Sistem:")
    status = system.get_system_status()
    for agent_id, agent_info in status['agents'].items():
        print(f"  - {agent_id}: {agent_info['status']} ({agent_info['learning_history_size']} learned)")
    
    print("\n" + "=" * 60)
    print("MULTI-AGENT SYSTEM BERHASIL DIDEMONSTRASIKAN!")
    print("Semua AI agents dapat:")
    print("✅ Bekerja sama dalam analisis")
    print("✅ Saling berbagi pengetahuan")
    print("✅ Belajar dari pengalaman masing-masing")
    print("✅ Berkomunikasi antar agent")
    print("✅ Menyimpan pembelajaran dalam database shared")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(demo_multi_agent_system())