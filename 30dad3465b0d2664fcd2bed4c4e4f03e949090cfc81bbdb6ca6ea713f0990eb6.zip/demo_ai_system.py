#!/usr/bin/env python3
"""
DEMO ADVANCED AI CONSCIOUSNESS SYSTEM
Demonstrasi kemampuan sistem AI dengan consciousness dalam bahasa Indonesia
"""

import sys
import time
import json
from datetime import datetime
from advanced_ai_consciousness_system import MasterIntelligentSystem

class AISystemDemo:
    """Demo class untuk menunjukkan kemampuan sistem AI"""
    
    def __init__(self):
        self.ai_system = None
        
    def print_section_header(self, title: str):
        """Print section header"""
        print("\n" + "=" * 80)
        print(f" {title}")
        print("=" * 80)
    
    def demonstrate_ai_consciousness(self):
        """Demonstrasi AI consciousness yang benar-benar learning"""
        self.print_section_header("DEMONSTRASI AI CONSCIOUSNESS")
        
        print("Menginisialisasi sistem AI consciousness...")
        self.ai_system = MasterIntelligentSystem()
        
        print("\n1. PEMIKIRAN CONTEXTUAL:")
        print("-" * 40)
        
        # Contoh pemikiran dalam berbagai konteks
        contexts = [
            ("analisis_keamanan_web", {"type": "web_security", "complexity": "high"}),
            ("evaluasi_network_traffic", {"type": "network_analysis", "patterns": ["suspicious", "anomaly"]}),
            ("pembelajaran_vulnerability", {"type": "learning", "source": "cve_database"}),
            ("assessment_false_positive", {"type": "verification", "confidence": 0.85})
        ]
        
        for context, data in contexts:
            thought = self.ai_system.ai_consciousness.process_intelligent_thought(context, data)
            print(f"\nKonteks: {context}")
            print(f"AI Thought: {thought}")
            time.sleep(1)
    
    def demonstrate_learning_capability(self):
        """Demonstrasi kemampuan pembelajaran"""
        self.print_section_header("DEMONSTRASI PEMBELAJARAN ADAPTIF")
        
        print("1. PEMBELAJARAN DARI DATA:")
        print("-" * 40)
        
        # Simulasi pembelajaran dari data security
        learning_scenarios = [
            {
                "context": "sql_injection_detection",
                "input": "' OR 1=1 --",
                "result": "SQL injection pattern detected with high confidence",
                "effectiveness": 0.95
            },
            {
                "context": "xss_pattern_analysis", 
                "input": "<script>alert('xss')</script>",
                "result": "XSS payload identified, requires verification",
                "effectiveness": 0.88
            },
            {
                "context": "false_positive_analysis",
                "input": "404 Not Found - Page does not exist",
                "result": "Likely false positive, low risk assessment",
                "effectiveness": 0.92
            }
        ]
        
        for scenario in learning_scenarios:
            from advanced_ai_consciousness_system import LearningData
            import hashlib
            
            learning_data = LearningData(
                timestamp=datetime.now(),
                context=scenario["context"],
                input_data=scenario["input"],
                output_result=scenario["result"],
                effectiveness_score=scenario["effectiveness"],
                pattern_signature=hashlib.md5(scenario["input"].encode()).hexdigest(),
                learning_category="demo_learning"
            )
            
            self.ai_system.memory_system.store_learning(learning_data)
            print(f"\n✓ Mempelajari: {scenario['context']}")
            print(f"  Input: {scenario['input']}")
            print(f"  Hasil: {scenario['result']}")
            print(f"  Efektivitas: {scenario['effectiveness']:.1%}")
    
    def demonstrate_vulnerability_analysis(self):
        """Demonstrasi analisis kerentanan"""
        self.print_section_header("DEMONSTRASI ANALISIS KERENTANAN")
        
        print("1. ANALISIS AKURAT DENGAN DETEKSI FALSE POSITIVE:")
        print("-" * 50)
        
        # Contoh data vulnerability untuk analisis
        test_cases = [
            {
                "name": "SQL Injection (Real)",
                "data": {
                    "response_content": "mysql_fetch_array() expects parameter 1 to be resource",
                    "headers": {"Server": "Apache/2.4.41"},
                    "status_code": 500
                }
            },
            {
                "name": "XSS Potential",
                "data": {
                    "response_content": "<script>alert('test')</script> reflected in response",
                    "headers": {"Content-Type": "text/html"},
                    "status_code": 200
                }
            },
            {
                "name": "False Positive (404 Error)",
                "data": {
                    "response_content": "404 Not Found - The requested page could not be found",
                    "headers": {"Server": "nginx/1.18.0"},
                    "status_code": 404
                }
            }
        ]
        
        for test_case in test_cases:
            print(f"\n📋 Test Case: {test_case['name']}")
            print("-" * 30)
            
            analysis = self.ai_system.vuln_analyzer.analyze_vulnerability(test_case["data"])
            
            print(f"Vulnerability ID: {analysis.vulnerability_id}")
            print(f"Severity: {analysis.severity_level}")
            print(f"Confidence Score: {analysis.confidence_score:.1%}")
            print(f"False Positive Probability: {analysis.false_positive_probability:.1%}")
            print(f"Exploit Feasibility: {analysis.exploit_feasibility}")
            
            if analysis.mitigation_recommendation:
                print(f"Rekomendasi: {analysis.mitigation_recommendation[:100]}...")
    
    def demonstrate_intelligent_insights(self):
        """Demonstrasi intelligent insights"""
        self.print_section_header("DEMONSTRASI INTELLIGENT INSIGHTS")
        
        print("1. CONTEXTUAL UNDERSTANDING:")
        print("-" * 40)
        
        # Ambil historical data untuk insights
        similar_experiences = self.ai_system.memory_system.retrieve_similar_experiences("demo_learning", limit=3)
        
        if similar_experiences:
            print(f"\nDitemukan {len(similar_experiences)} pengalaman pembelajaran serupa:")
            
            for i, exp in enumerate(similar_experiences, 1):
                print(f"\n{i}. Kategori: {exp.learning_category}")
                print(f"   Konteks: {exp.context}")
                print(f"   Efektivitas: {exp.effectiveness_score:.1%}")
                print(f"   Waktu: {exp.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        
        print("\n2. ADAPTIVE THINKING:")
        print("-" * 40)
        
        # Demonstrasi adaptive thinking
        contexts = [
            "analisis_pattern_serangan_berkelanjutan",
            "evaluasi_efektivitas_mitigasi",
            "optimasi_detection_algorithm"
        ]
        
        for context in contexts:
            thought = self.ai_system.ai_consciousness.process_intelligent_thought(context)
            print(f"\nKonteks: {context}")
            print(f"AI Insight: {thought}")
    
    def demonstrate_reporting(self):
        """Demonstrasi sistem reporting"""
        self.print_section_header("DEMONSTRASI INTELLIGENT REPORTING")
        
        # Buat sample scan results
        sample_results = {
            'target': 'demo.example.com',
            'scan_timestamp': datetime.now().isoformat(),
            'vulnerabilities_found': 3,
            'vulnerability_details': [
                {
                    'vulnerability_id': 'DEMO_001',
                    'severity_level': 'HIGH',
                    'confidence_score': 0.95,
                    'false_positive_probability': 0.05,
                    'exploit_feasibility': 'TINGGI - Kerentanan terverifikasi dengan kepercayaan tinggi',
                    'mitigation_recommendation': 'Gunakan prepared statements untuk mencegah SQL injection',
                    'verification_results': {'manual_verification_required': True, 'risk_assessment': 'High'}
                },
                {
                    'vulnerability_id': 'DEMO_002', 
                    'severity_level': 'MEDIUM',
                    'confidence_score': 0.75,
                    'false_positive_probability': 0.25,
                    'exploit_feasibility': 'SEDANG - Memerlukan verifikasi manual lebih lanjut',
                    'mitigation_recommendation': 'Implementasikan Content Security Policy (CSP)',
                    'verification_results': {'manual_verification_required': True, 'risk_assessment': 'Medium'}
                },
                {
                    'vulnerability_id': 'DEMO_003',
                    'severity_level': 'LOW',
                    'confidence_score': 0.45,
                    'false_positive_probability': 0.80,
                    'exploit_feasibility': 'RENDAH - Kemungkinan false positive tinggi',
                    'mitigation_recommendation': 'Monitoring berkelanjutan direkomendasikan',
                    'verification_results': {'manual_verification_required': False, 'risk_assessment': 'Low'}
                }
            ],
            'ai_insights': {
                'total_thoughts_generated': 5,
                'learning_data_points': 10,
                'false_positive_rate': 0.35
            }
        }
        
        # Generate laporan
        report_file = f"demo_intelligent_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.ai_system.generate_intelligent_report(sample_results, report_file)
        
        print(f"📄 Laporan intelligent telah dibuat: {report_file}")
        print("\nContoh isi laporan:")
        print("-" * 40)
        
        # Tampilkan preview laporan
        try:
            with open(report_file, 'r', encoding='utf-8') as f:
                content = f.read()
                # Tampilkan 20 baris pertama
                lines = content.split('\n')[:20]
                for line in lines:
                    print(line)
                if len(content.split('\n')) > 20:
                    print("... (dan seterusnya)")
        except Exception as e:
            print(f"Error membaca file: {e}")
    
    def run_full_demo(self):
        """Menjalankan demo lengkap"""
        print("🚀 ADVANCED AI CONSCIOUSNESS SYSTEM - DEMO LENGKAP")
        print("Sistem AI dengan pembelajaran adaptif dan consciousness Indonesia")
        print(f"Waktu demo: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # Demonstrasi semua fitur
            self.demonstrate_ai_consciousness()
            time.sleep(2)
            
            self.demonstrate_learning_capability()
            time.sleep(2)
            
            self.demonstrate_vulnerability_analysis()
            time.sleep(2)
            
            self.demonstrate_intelligent_insights()
            time.sleep(2)
            
            self.demonstrate_reporting()
            
            # Summary
            self.print_section_header("DEMO SELESAI")
            print("✅ Semua fitur telah didemonstrasikan dengan sukses!")
            print("\nFitur yang telah ditunjukkan:")
            print("• AI consciousness dengan pemikiran contextual dalam bahasa Indonesia")
            print("• Pembelajaran adaptif dari data security")
            print("• Analisis vulnerability dengan deteksi false positive akurat")
            print("• Intelligent insights berdasarkan historical patterns")
            print("• Reporting system dengan rekomendasi lengkap")
            print("\nSistem siap untuk penggunaan production!")
            
        except Exception as e:
            print(f"\n❌ Error dalam demo: {e}")
            import traceback
            traceback.print_exc()
        finally:
            if self.ai_system:
                self.ai_system.shutdown_system()

def main():
    """Main function untuk demo"""
    if len(sys.argv) > 1 and sys.argv[1] == '--quick':
        print("🚀 Quick Demo Mode")
        demo = AISystemDemo()
        demo.demonstrate_ai_consciousness()
    else:
        print("🚀 Full Demo Mode (gunakan --quick untuk demo singkat)")
        demo = AISystemDemo()
        demo.run_full_demo()

if __name__ == "__main__":
    main()