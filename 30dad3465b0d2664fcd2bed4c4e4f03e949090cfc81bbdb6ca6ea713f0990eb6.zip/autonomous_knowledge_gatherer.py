#!/usr/bin/env python3
"""
AUTONOMOUS KNOWLEDGE GATHERING SYSTEM
Sistem pencarian data otomatis untuk AI collective consciousness
Mencari vulnerability data, threat intelligence, dan security updates terbaru
"""

import asyncio
import aiohttp
import json
import sqlite3
import hashlib
import time
import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import feedparser
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

class AutonomousKnowledgeGatherer:
    """AI system yang secara otomatis mencari dan mengumpulkan pengetahuan dari internet"""
    
    def __init__(self, database_path: str = "autonomous_knowledge.db"):
        self.db_path = database_path
        self.session = None
        self.is_active = False
        self.gathering_thread = None
        self.setup_database()
        self.setup_logging()
        
        # Sources untuk pencarian data
        self.vulnerability_sources = [
            "https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=",
            "https://nvd.nist.gov/vuln/search/results?form_type=Basic&results_type=overview&search_type=all&query=",
            "https://www.exploit-db.com/search?q=",
            "https://vuldb.com/?search="
        ]
        
        self.security_feeds = [
            "https://feeds.feedburner.com/securityweek",
            "https://threatpost.com/feed/",
            "https://feeds.feedburner.com/eset/blog",
            "https://blog.malwarebytes.com/feed/",
            "https://feeds.feedburner.com/TheHackersNews"
        ]
        
        self.threat_intelligence_sources = [
            "https://otx.alienvault.com/api/v1/pulses/",
            "https://api.abuse.ch/api/",
            "https://urlhaus-api.abuse.ch/v1/"
        ]
        
        # Knowledge categories
        self.knowledge_categories = [
            "vulnerability_research",
            "exploit_techniques", 
            "security_tools",
            "threat_intelligence",
            "penetration_testing",
            "incident_response",
            "malware_analysis",
            "network_security"
        ]
        
    def setup_logging(self):
        """Setup logging system"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger("KnowledgeGatherer")
        
    def setup_database(self):
        """Setup database untuk menyimpan knowledge yang dikumpulkan"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Table untuk menyimpan raw data yang dikumpulkan
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS gathered_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_url TEXT NOT NULL,
                source_type TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT,
                content TEXT,
                metadata TEXT,
                content_hash TEXT UNIQUE,
                relevance_score REAL DEFAULT 0.0,
                is_processed BOOLEAN DEFAULT FALSE,
                gathered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Table untuk vulnerability data
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vulnerability_intelligence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cve_id TEXT UNIQUE,
                cvss_score REAL,
                description TEXT,
                affected_systems TEXT,
                exploit_available BOOLEAN DEFAULT FALSE,
                patch_available BOOLEAN DEFAULT FALSE,
                discovery_date DATE,
                disclosure_date DATE,
                raw_data TEXT,
                source_urls TEXT,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Table untuk threat intelligence
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS threat_intelligence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                indicator_type TEXT NOT NULL,
                indicator_value TEXT NOT NULL,
                threat_type TEXT,
                confidence_level REAL,
                first_seen DATE,
                last_seen DATE,
                description TEXT,
                source_url TEXT,
                metadata TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Table untuk learning patterns
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learning_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT NOT NULL,
                pattern_data TEXT NOT NULL,
                frequency INTEGER DEFAULT 1,
                effectiveness_score REAL DEFAULT 0.0,
                context_metadata TEXT,
                learned_from TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Table untuk search queries dan results
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS search_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT NOT NULL,
                source_type TEXT,
                results_count INTEGER,
                relevant_results INTEGER,
                success_rate REAL,
                searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
        
    async def start_autonomous_gathering(self):
        """Memulai proses autonomous knowledge gathering"""
        if self.is_active:
            self.logger.warning("Knowledge gathering sudah aktif")
            return
            
        self.is_active = True
        self.logger.info("Memulai autonomous knowledge gathering...")
        
        # Create aiohttp session
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            headers={
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        )
        
        # Start gathering loop in background
        self.gathering_thread = asyncio.create_task(self.knowledge_gathering_loop())
    
    async def start_continuous_gathering(self):
        """Alias untuk start_autonomous_gathering"""
        return await self.start_autonomous_gathering()
        
        self.logger.info("Autonomous knowledge gathering dimulai")
        
    async def stop_autonomous_gathering(self):
        """Menghentikan proses gathering"""
        self.is_active = False
        
        if self.gathering_thread:
            self.gathering_thread.cancel()
            
        if self.session:
            await self.session.close()
            
        self.logger.info("Knowledge gathering dihentikan")
        
    async def knowledge_gathering_loop(self):
        """Main loop untuk autonomous gathering"""
        gather_count = 0
        
        while self.is_active:
            try:
                self.logger.info(f"Starting knowledge gathering cycle #{gather_count + 1}")
                
                # 1. Gather from security feeds
                await self.gather_from_security_feeds()
                
                # 2. Search for new vulnerabilities
                await self.search_vulnerability_databases()
                
                # 3. Collect threat intelligence
                await self.collect_threat_intelligence()
                
                # 4. Research specific topics
                await self.autonomous_topic_research()
                
                # 5. Process dan learn dari data yang dikumpulkan
                await self.process_gathered_knowledge()
                
                # 6. Update learning patterns
                await self.update_learning_patterns()
                
                gather_count += 1
                self.logger.info(f"Knowledge gathering cycle #{gather_count} completed")
                
                # Wait sebelum cycle berikutnya (30 menit)
                await asyncio.sleep(1800)  # 30 minutes
                
            except asyncio.CancelledError:
                self.logger.info("Knowledge gathering loop dibatalkan")
                break
            except Exception as e:
                self.logger.error(f"Error dalam gathering loop: {e}")
                await asyncio.sleep(300)  # Wait 5 minutes sebelum retry
                
    async def gather_from_security_feeds(self):
        """Mengumpulkan data dari security news feeds"""
        self.logger.info("Gathering data dari security feeds...")
        
        for feed_url in self.security_feeds:
            try:
                # Parse RSS feed
                feed = feedparser.parse(feed_url)
                
                for entry in feed.entries[:10]:  # Ambil 10 entry terbaru
                    title = entry.get('title', '')
                    description = entry.get('description', '')
                    link = entry.get('link', '')
                    published = entry.get('published', '')
                    
                    # Calculate relevance score
                    relevance = self.calculate_security_relevance(title + " " + description)
                    
                    if relevance > 0.5:  # Only save yang relevant
                        await self.save_knowledge_item(
                            source_url=link,
                            source_type="security_feed",
                            category="security_news",
                            title=title,
                            content=description,
                            metadata=json.dumps({
                                "published": published,
                                "feed_source": feed_url,
                                "relevance_score": relevance
                            }),
                            relevance_score=relevance
                        )
                        
                self.logger.info(f"Processed feed: {feed_url}")
                
            except Exception as e:
                self.logger.error(f"Error processing feed {feed_url}: {e}")
                
    async def search_vulnerability_databases(self):
        """Mencari vulnerability data terbaru"""
        self.logger.info("Searching vulnerability databases...")
        
        # Generate search queries berdasarkan trend terkini
        search_queries = await self.generate_intelligent_queries()
        
        for query in search_queries[:5]:  # Limit untuk tidak overwhelm
            await self.search_cve_data(query)
            await asyncio.sleep(2)  # Rate limiting
            
    async def generate_intelligent_queries(self) -> List[str]:
        """Generate search queries yang intelligent berdasarkan learning"""
        # Base queries yang selalu relevant
        base_queries = [
            "remote code execution",
            "sql injection",
            "cross site scripting",
            "privilege escalation",
            "authentication bypass"
        ]
        
        # Get trending topics dari database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT pattern_data FROM learning_patterns 
            WHERE pattern_type = 'trending_vulnerability'
            ORDER BY frequency DESC, last_used DESC
            LIMIT 10
        """)
        
        trending = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        # Combine base dengan trending
        all_queries = base_queries + trending
        
        # Add current year untuk latest vulns
        current_year = datetime.now().year
        yearly_queries = [f"{query} {current_year}" for query in all_queries[:3]]
        
        return all_queries + yearly_queries
        
    async def search_cve_data(self, query: str):
        """Search CVE data untuk query tertentu"""
        try:
            # Simple CVE search (dalam implementasi real, gunakan official API)
            search_url = f"https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword={query.replace(' ', '+')}"
            
            async with self.session.get(search_url) as response:
                if response.status == 200:
                    content = await response.text()
                    
                    # Extract CVE IDs dari content
                    cve_pattern = r'CVE-\d{4}-\d{4,}'
                    cve_ids = re.findall(cve_pattern, content)
                    
                    for cve_id in cve_ids[:5]:  # Limit results
                        await self.fetch_cve_details(cve_id)
                        
                    # Save search history
                    await self.save_search_history(query, "cve_search", len(cve_ids), len(cve_ids))
                    
        except Exception as e:
            self.logger.error(f"Error searching CVE for query '{query}': {e}")
            
    async def fetch_cve_details(self, cve_id: str):
        """Fetch detail CVE tertentu"""
        try:
            # Check if sudah ada di database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM vulnerability_intelligence WHERE cve_id = ?", (cve_id,))
            
            if cursor.fetchone():
                conn.close()
                return  # Already exists
                
            conn.close()
            
            # Fetch CVE details (simulasi - dalam real implementation gunakan NVD API)
            cve_url = f"https://cve.mitre.org/cgi-bin/cvename.cgi?name={cve_id}"
            
            async with self.session.get(cve_url) as response:
                if response.status == 200:
                    content = await response.text()
                    soup = BeautifulSoup(content, 'html.parser')
                    
                    # Extract description
                    description = ""
                    desc_elements = soup.find_all(text=re.compile(r'Description|Summary'))
                    if desc_elements:
                        parent = desc_elements[0].parent
                        if parent:
                            description = parent.get_text().strip()
                    
                    # Save ke database
                    await self.save_vulnerability_data(
                        cve_id=cve_id,
                        description=description,
                        source_url=cve_url,
                        raw_data=content[:5000]  # Limit size
                    )
                    
                    self.logger.info(f"Fetched CVE details: {cve_id}")
                    
        except Exception as e:
            self.logger.error(f"Error fetching CVE {cve_id}: {e}")
            
    async def collect_threat_intelligence(self):
        """Mengumpulkan threat intelligence data"""
        self.logger.info("Collecting threat intelligence...")
        
        # Simulasi collection dari berbagai sources
        # Dalam implementasi real, integrate dengan AlienVault OTX, etc.
        
        sample_indicators = [
            {"type": "domain", "value": "malicious-domain.com", "threat_type": "malware_c2"},
            {"type": "ip", "value": "192.168.1.100", "threat_type": "scanning_activity"},
            {"type": "hash", "value": "d41d8cd98f00b204e9800998ecf8427e", "threat_type": "malware_sample"}
        ]
        
        for indicator in sample_indicators:
            await self.save_threat_indicator(
                indicator_type=indicator["type"],
                indicator_value=indicator["value"],
                threat_type=indicator["threat_type"],
                confidence_level=0.7,
                source_url="autonomous_collection"
            )
            
    async def autonomous_topic_research(self):
        """Research autonomous untuk topik-topik security terbaru"""
        self.logger.info("Conducting autonomous topic research...")
        
        # Generate research topics berdasarkan current trends
        research_topics = [
            "zero day vulnerabilities 2025",
            "latest ransomware techniques",
            "AI security threats",
            "cloud security vulnerabilities",
            "IoT device exploits"
        ]
        
        for topic in research_topics:
            await self.research_topic(topic)
            await asyncio.sleep(3)  # Rate limiting
            
    async def research_topic(self, topic: str):
        """Research topik tertentu secara mendalam"""
        try:
            # Search di Google untuk topic (simulasi)
            search_query = f"{topic} site:exploit-db.com OR site:cve.mitre.org OR site:nvd.nist.gov"
            
            # Dalam implementasi real, gunakan Google Search API atau scraping
            self.logger.info(f"Researching topic: {topic}")
            
            # Save research pattern
            await self.save_learning_pattern(
                pattern_type="research_topic",
                pattern_data=topic,
                context_metadata=json.dumps({"auto_generated": True, "timestamp": datetime.now().isoformat()})
            )
            
        except Exception as e:
            self.logger.error(f"Error researching topic '{topic}': {e}")
            
    async def process_gathered_knowledge(self):
        """Process dan analyze knowledge yang sudah dikumpulkan"""
        self.logger.info("Processing gathered knowledge...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get unprocessed knowledge
        cursor.execute("""
            SELECT id, content, category, title 
            FROM gathered_knowledge 
            WHERE is_processed = FALSE
            LIMIT 50
        """)
        
        unprocessed = cursor.fetchall()
        
        for item_id, content, category, title in unprocessed:
            try:
                # Analyze content untuk extract insights
                insights = await self.analyze_content_insights(content, title)
                
                # Update processed status
                cursor.execute(
                    "UPDATE gathered_knowledge SET is_processed = TRUE, last_updated = CURRENT_TIMESTAMP WHERE id = ?",
                    (item_id,)
                )
                
                # Save insights sebagai learning patterns
                for insight in insights:
                    await self.save_learning_pattern(
                        pattern_type="content_insight",
                        pattern_data=insight,
                        context_metadata=json.dumps({"source_id": item_id, "category": category})
                    )
                    
            except Exception as e:
                self.logger.error(f"Error processing knowledge item {item_id}: {e}")
                
        conn.commit()
        conn.close()
        
        self.logger.info(f"Processed {len(unprocessed)} knowledge items")
        
    async def analyze_content_insights(self, content: str, title: str) -> List[str]:
        """Analyze content untuk extract actionable insights"""
        insights = []
        
        # Simple keyword extraction (dalam real implementation, gunakan NLP)
        security_keywords = [
            "exploit", "vulnerability", "CVE", "patch", "malware", 
            "ransomware", "phishing", "injection", "overflow", "bypass"
        ]
        
        content_lower = content.lower()
        title_lower = title.lower()
        
        for keyword in security_keywords:
            if keyword in content_lower or keyword in title_lower:
                insights.append(f"security_keyword:{keyword}")
                
        # Extract potential CVE IDs
        cve_pattern = r'CVE-\d{4}-\d{4,}'
        cve_matches = re.findall(cve_pattern, content + " " + title)
        
        for cve in cve_matches:
            insights.append(f"referenced_cve:{cve}")
            
        return insights
        
    async def update_learning_patterns(self):
        """Update learning patterns berdasarkan data terbaru"""
        self.logger.info("Updating learning patterns...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Update frequency patterns
        cursor.execute("""
            UPDATE learning_patterns 
            SET frequency = frequency + 1, last_used = CURRENT_TIMESTAMP
            WHERE pattern_type = 'trending_vulnerability'
            AND pattern_data IN (
                SELECT DISTINCT category FROM gathered_knowledge 
                WHERE gathered_at > datetime('now', '-1 day')
            )
        """)
        
        conn.commit()
        conn.close()
        
    def calculate_security_relevance(self, text: str) -> float:
        """Calculate relevance score untuk security content"""
        if not text:
            return 0.0
            
        text_lower = text.lower()
        
        # Security-related keywords dengan weights
        security_terms = {
            'vulnerability': 0.9,
            'exploit': 0.9,
            'cve': 0.8,
            'security': 0.7,
            'malware': 0.8,
            'ransomware': 0.8,
            'phishing': 0.7,
            'breach': 0.8,
            'attack': 0.6,
            'threat': 0.6,
            'hack': 0.5,
            'penetration': 0.7,
            'injection': 0.8,
            'overflow': 0.7
        }
        
        total_score = 0.0
        found_terms = 0
        
        for term, weight in security_terms.items():
            if term in text_lower:
                total_score += weight
                found_terms += 1
                
        if found_terms == 0:
            return 0.0
            
        # Normalize score
        normalized_score = min(total_score / found_terms, 1.0)
        
        # Boost score jika banyak term yang ditemukan
        term_density_bonus = min(found_terms / len(security_terms), 0.3)
        
        return min(normalized_score + term_density_bonus, 1.0)
        
    async def save_knowledge_item(self, source_url: str, source_type: str, category: str, 
                                 title: str, content: str, metadata: str, relevance_score: float):
        """Save knowledge item ke database"""
        content_hash = hashlib.md5((source_url + content).encode()).hexdigest()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT OR IGNORE INTO gathered_knowledge 
                (source_url, source_type, category, title, content, metadata, content_hash, relevance_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (source_url, source_type, category, title, content, metadata, content_hash, relevance_score))
            
            conn.commit()
        except sqlite3.IntegrityError:
            pass  # Already exists
        finally:
            conn.close()
            
    async def save_vulnerability_data(self, cve_id: str, description: str, source_url: str, raw_data: str):
        """Save vulnerability data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO vulnerability_intelligence 
            (cve_id, description, raw_data, source_urls)
            VALUES (?, ?, ?, ?)
        """, (cve_id, description, raw_data, source_url))
        
        conn.commit()
        conn.close()
        
    async def save_threat_indicator(self, indicator_type: str, indicator_value: str, 
                                  threat_type: str, confidence_level: float, source_url: str):
        """Save threat intelligence indicator"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO threat_intelligence 
            (indicator_type, indicator_value, threat_type, confidence_level, source_url)
            VALUES (?, ?, ?, ?, ?)
        """, (indicator_type, indicator_value, threat_type, confidence_level, source_url))
        
        conn.commit()
        conn.close()
        
    async def save_learning_pattern(self, pattern_type: str, pattern_data: str, context_metadata: str):
        """Save learning pattern"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if pattern exists
        cursor.execute(
            "SELECT id, frequency FROM learning_patterns WHERE pattern_type = ? AND pattern_data = ?",
            (pattern_type, pattern_data)
        )
        
        existing = cursor.fetchone()
        
        if existing:
            # Update frequency
            cursor.execute(
                "UPDATE learning_patterns SET frequency = frequency + 1, last_used = CURRENT_TIMESTAMP WHERE id = ?",
                (existing[0],)
            )
        else:
            # Insert new pattern
            cursor.execute("""
                INSERT INTO learning_patterns (pattern_type, pattern_data, context_metadata)
                VALUES (?, ?, ?)
            """, (pattern_type, pattern_data, context_metadata))
            
        conn.commit()
        conn.close()
        
    async def save_search_history(self, query: str, source_type: str, results_count: int, relevant_results: int):
        """Save search history"""
        success_rate = relevant_results / results_count if results_count > 0 else 0.0
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO search_history (query, source_type, results_count, relevant_results, success_rate)
            VALUES (?, ?, ?, ?, ?)
        """, (query, source_type, results_count, relevant_results, success_rate))
        
        conn.commit()
        conn.close()
        
    def get_knowledge_stats(self) -> Dict[str, Any]:
        """Get statistik knowledge yang dikumpulkan"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        stats = {}
        
        # Total knowledge items
        cursor.execute("SELECT COUNT(*) FROM gathered_knowledge")
        stats['total_knowledge'] = cursor.fetchone()[0]
        
        # Processed items
        cursor.execute("SELECT COUNT(*) FROM gathered_knowledge WHERE is_processed = TRUE")
        stats['processed_knowledge'] = cursor.fetchone()[0]
        
        # Vulnerability count
        cursor.execute("SELECT COUNT(*) FROM vulnerability_intelligence")
        stats['vulnerabilities'] = cursor.fetchone()[0]
        
        # Threat indicators
        cursor.execute("SELECT COUNT(*) FROM threat_intelligence")
        stats['threat_indicators'] = cursor.fetchone()[0]
        
        # Learning patterns
        cursor.execute("SELECT COUNT(*) FROM learning_patterns")
        stats['learning_patterns'] = cursor.fetchone()[0]
        
        # Recent activity (last 24 hours)
        cursor.execute("""
            SELECT COUNT(*) FROM gathered_knowledge 
            WHERE gathered_at > datetime('now', '-1 day')
        """)
        stats['recent_knowledge'] = cursor.fetchone()[0]
        
        conn.close()
        
        return stats
        
    def get_trending_topics(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get trending security topics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT pattern_data, frequency, last_used 
            FROM learning_patterns 
            WHERE pattern_type = 'content_insight'
            ORDER BY frequency DESC, last_used DESC
            LIMIT ?
        """, (limit,))
        
        trends = []
        for pattern_data, frequency, last_used in cursor.fetchall():
            trends.append({
                'topic': pattern_data,
                'frequency': frequency,
                'last_seen': last_used
            })
            
        conn.close()
        return trends
        
    async def manual_search(self, query: str, category: str = "manual_search") -> Dict[str, Any]:
        """Manual search untuk query tertentu"""
        self.logger.info(f"Manual search untuk: {query}")
        
        if not self.session:
            await self.start_autonomous_gathering()
            
        # Perform search
        await self.search_cve_data(query)
        
        # Return results
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT title, content, source_url, relevance_score
            FROM gathered_knowledge 
            WHERE content LIKE ? OR title LIKE ?
            ORDER BY relevance_score DESC, gathered_at DESC
            LIMIT 10
        """, (f"%{query}%", f"%{query}%"))
        
        results = []
        for title, content, source_url, relevance_score in cursor.fetchall():
            results.append({
                'title': title,
                'content': content[:500] + "..." if len(content) > 500 else content,
                'source_url': source_url,
                'relevance_score': relevance_score
            })
            
        conn.close()
        
        return {
            'query': query,
            'results_count': len(results),
            'results': results
        }

# Test dan demo function
async def demo_autonomous_knowledge_gathering():
    """Demo autonomous knowledge gathering system"""
    print("\n=== AUTONOMOUS KNOWLEDGE GATHERING SYSTEM DEMO ===")
    print("AI system yang mencari dan mengumpulkan pengetahuan secara otomatis\n")
    
    gatherer = AutonomousKnowledgeGatherer()
    
    try:
        # Start autonomous gathering
        await gatherer.start_autonomous_gathering()
        
        print("[INFO] Autonomous gathering dimulai...")
        print("[INFO] System akan mencari data security terbaru dari internet...")
        
        # Let it run untuk beberapa saat
        await asyncio.sleep(10)
        
        # Show stats
        stats = gatherer.get_knowledge_stats()
        print(f"\n[STATS] Knowledge Statistics:")
        for key, value in stats.items():
            print(f"  {key}: {value}")
            
        # Show trending topics
        trends = gatherer.get_trending_topics(5)
        print(f"\n[TRENDS] Trending Security Topics:")
        for trend in trends:
            print(f"  - {trend['topic']} (frequency: {trend['frequency']})")
            
        # Manual search demo
        search_result = await gatherer.manual_search("sql injection")
        print(f"\n[SEARCH] Manual search results for 'sql injection':")
        print(f"  Found {search_result['results_count']} results")
        
    finally:
        await gatherer.stop_autonomous_gathering()
        print("\n[INFO] Demo selesai")

if __name__ == "__main__":
    asyncio.run(demo_autonomous_knowledge_gathering())
