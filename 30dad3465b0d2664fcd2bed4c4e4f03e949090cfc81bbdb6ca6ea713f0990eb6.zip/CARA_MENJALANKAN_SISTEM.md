# 🎯 PANDUAN LENGKAP - CARA MENJALANKAN MEGA AI ECOSYSTEM

## 🔧 **PERSIAPAN AWAL**

### 1. **Extract ZIP File**
```bash
# Download dan extract
unzip MEGA_AI_ECOSYSTEM_COMPLETE.zip
cd MEGA_AI_ECOSYSTEM_COMPLETE/

# Berikan permission untuk script
chmod +x ULTIMATE_MASTER_LAUNCHER.sh
```

### 2. **Cek Requirements**
```bash
# Cek Python version (minimal Python 3.8+)
python3 --version

# Install dependencies
pip3 install -r requirements.txt
```

## 🚀 **CARA MENJALANKAN SISTEM**

### **METODE 1: QUICK START (Paling Mudah)**
```bash
# Jalankan mode quick - startup cepat dengan core systems
./ULTIMATE_MASTER_LAUNCHER.sh quick
```

### **METODE 2: LIHAT SEMUA OPTIONS**
```bash
# Lihat semua mode yang tersedia
./ULTIMATE_MASTER_LAUNCHER.sh --help
```

### **METODE 3: MODE-MODE LAINNYA**

#### **🔍 Comprehensive Mode (Semua System)**
```bash
./ULTIMATE_MASTER_LAUNCHER.sh comprehensive
```

#### **🕵️ Deep Analysis Mode**
```bash
./ULTIMATE_MASTER_LAUNCHER.sh deep
```

#### **⚡ Zero-Day Hunting Mode**
```bash
./ULTIMATE_MASTER_LAUNCHER.sh zero-day
```

#### **🥷 Stealth Mode (Background)**
```bash
./ULTIMATE_MASTER_LAUNCHER.sh stealth
```

#### **🔬 Research Mode**
```bash
./ULTIMATE_MASTER_LAUNCHER.sh research
```

## 🎛️ **ADVANCED OPTIONS**

### **Custom Configuration**
```bash
# Jalankan dengan custom config
./ULTIMATE_MASTER_LAUNCHER.sh --mode deep --verbose --log-level debug
```

### **Specific AI System**
```bash
# Jalankan hanya AI Collective Consciousness
python3 ai_collective_consciousness.py

# Jalankan hanya Zero-Day Engine
python3 THE-CHIMERA-ENIGMA-QUANTUM-COMPLETE-FIXED/THE-CHIMERA-ENIGMA-QUANTUM-COMPLETE/quantum_core/zero_day_discovery_engine.py

# Jalankan hanya Vulnerability Scanner
python3 ai_vulnerability_scanner.py
```

## 📊 **MONITORING & DEBUGGING**

### **Lihat Status System**
```bash
# Monitor performance
python3 monitor_ai_performance.py

# Test semua systems
python3 test_ai_systems.py

# Lihat log real-time
tail -f *.log
```

### **Troubleshooting**
```bash
# Jika ada error, cek system verification
./ULTIMATE_MASTER_LAUNCHER.sh --verify-only

# Force restart semua process
./ULTIMATE_MASTER_LAUNCHER.sh --restart-all
```

## 🎯 **REKOMENDASI PENGGUNAAN**

### **🏃‍♂️ Untuk Pemula:**
```bash
# Start dengan mode quick
./ULTIMATE_MASTER_LAUNCHER.sh quick
```

### **👨‍💼 Untuk Professional:**
```bash
# Gunakan comprehensive mode
./ULTIMATE_MASTER_LAUNCHER.sh comprehensive --verbose
```

### **🔒 Untuk Security Testing:**
```bash
# Gunakan zero-day mode
./ULTIMATE_MASTER_LAUNCHER.sh zero-day --stealth
```

## ⚠️ **IMPORTANT NOTES**

1. **First Run:** Sistem akan melakukan setup otomatis pada run pertama
2. **Resource Usage:** Mode `deep` dan `zero-day` membutuhkan resource CPU/RAM yang tinggi
3. **Network:** Beberapa fitur memerlukan koneksi internet untuk API calls
4. **Permissions:** Pastikan script memiliki execute permission (`chmod +x`)

## 🔧 **JIKA ADA MASALAH**

### **Error Python Dependencies:**
```bash
pip3 install --upgrade pip
pip3 install -r requirements.txt --force-reinstall
```

### **Error Permission:**
```bash
chmod +x *.sh
chmod +x *.py
```

### **Error Memory:**
```bash
# Gunakan mode quick jika RAM terbatas
./ULTIMATE_MASTER_LAUNCHER.sh quick --low-resource
```

## 🎉 **SELAMAT MENGGUNAKAN!**

Sistem sudah siap digunakan dengan berbagai mode operasi. Pilih mode sesuai kebutuhan dan resource yang tersedia.