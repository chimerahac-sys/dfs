#!/bin/bash

# Quick launcher for AI system
TARGET="$1"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target_domain>"
    echo "Example: $0 example.com"
    exit 1
fi

echo "🚀 Launching AI system for target: $TARGET"

# Go to the main directory
cd THE-CHIMERA-ENIGMA-QUANTUM-COMPLETE

# Run the main system
if [ -f "ai.sh" ]; then
    chmod +x ai.sh
    ./ai.sh "$TARGET"
elif [ -f "the_chimera_enigma_quantum_complete.py" ]; then
    python3 the_chimera_enigma_quantum_complete.py --target "$TARGET"
else
    echo "❌ Main system files not found"
    exit 1
fi
