#!/bin/bash

# =============================================================================
#    Advanced AI Consciousness System - Intelligent Security Scanner
# =============================================================================
#  ** NOTICE: Gunakan ULTIMATE_MASTER_LAUNCHER.sh untuk integrasi penuh! **
#  
#  Script ini dapat digunakan secara standalone, TAPI untuk mendapatkan
#  kekuatan PENUH dari AI Collective dengan semua agents:
#  
#  GUNAKAN:  ./ULTIMATE_MASTER_LAUNCHER.sh <target> [mode]
#  
#  ULTIMATE_MASTER_LAUNCHER.sh mengintegrasikan:
#    - AI Collective Consciousness (6 specialized agents)
#    - Advanced AI Consciousness System (script ini)
#    - Multi-Agent AI System
#    - Intelligent Scanner
#    - Dan semua module lainnya dalam satu eksekusi yang terkoordinasi!
#  
#  Genuine AI-powered vulnerability assessment with learning capabilities
#  by MiniMax Agent - Real intelligence, not fake scripts
# =============================================================================

TARGET="$1"
SCAN_TYPE="${2:-comprehensive}"

# Colors for clean output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Clean logging functions
function log() { echo -e "${BLUE}[INFO]${NC} $1"; }
function success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
function warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
function error() { echo -e "${RED}[ERROR]${NC} $1"; }

function show_banner() {
    clear
    echo ""
    echo "================================================================"
    echo "    Advanced AI Consciousness System v2.0"
    echo "    Intelligent Security Assessment Platform"
    echo "================================================================"
    echo "  Target: ${TARGET:-Not specified}"
    echo "  Mode: $SCAN_TYPE"
    echo "  Status: Real AI Intelligence Active"
    echo "================================================================"
    echo ""
    echo -e "${YELLOW}[RECOMMENDATION]${NC} For FULL AI collective power with 6 agents:"
    echo -e "${CYAN}  ./ULTIMATE_MASTER_LAUNCHER.sh $TARGET $SCAN_TYPE${NC}"
    echo ""
    echo "  This standalone script provides single AI functionality."
    echo "  ULTIMATE_MASTER_LAUNCHER.sh provides collective intelligence!"
    echo "================================================================"
    echo ""
}

function check_requirements() {
    log "Checking system requirements..."
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        error "Python3 is required but not installed"
        exit 1
    fi
    
    # Check if AI system exists
    if [ ! -f "advanced_ai_consciousness_system.py" ]; then
        error "Advanced AI Consciousness System not found"
        error "Please ensure all system files are in the current directory"
        exit 1
    fi
    
    # Install requirements if needed
    if [ -f "requirements.txt" ]; then
        log "Installing Python dependencies..."
        pip3 install -r requirements.txt --quiet --user 2>/dev/null
    fi
    
    success "System requirements satisfied"
}

function initialize_ai() {
    log "Initializing AI Consciousness System..."
    
    # Initialize AI database and models
    python3 -c "
from advanced_ai_consciousness_system import AdvancedAIConsciousness
ai = AdvancedAIConsciousness()
ai.initialize_learning_system()
print('AI consciousness initialized successfully')
" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        success "AI consciousness activated"
    else
        warning "AI initialization had some issues, but continuing..."
    fi
}

function run_ai_scan() {
    local target="$1"
    local scan_type="$2"
    
    if [ -z "$target" ]; then
        log "Interactive mode - launching AI system menu..."
        python3 run.py
        return
    fi
    
    log "Starting AI-powered security assessment for: $target"
    
    # Run the intelligent scanner
    python3 intelligent_scanner.py "$target" --scan-type "$scan_type"
    
    if [ $? -eq 0 ]; then
        success "AI security assessment completed successfully"
        echo ""
        log "Results have been saved with AI analysis and recommendations"
        log "The AI has learned from this scan and improved its capabilities"
    else
        error "AI scan encountered issues"
        return 1
    fi
}

function show_usage() {
    echo ""
    echo "Usage: $0 [target] [scan_type]"
    echo ""
    echo "Arguments:"
    echo "  target     Target URL or IP (optional - will use interactive mode if not provided)"
    echo "  scan_type  Type of scan: quick, comprehensive, deep (default: comprehensive)"
    echo ""
    echo "Examples:"
    echo "  $0                              # Interactive mode with menu"
    echo "  $0 example.com                  # Comprehensive scan of example.com"
    echo "  $0 192.168.1.1 quick          # Quick scan of IP address"
    echo "  $0 https://target.com deep     # Deep scan with maximum AI analysis"
    echo ""
    echo "Features:"
    echo "  - Real AI consciousness with learning capabilities"
    echo "  - Natural language vulnerability analysis in Indonesian"
    echo "  - False positive detection and classification"
    echo "  - Web-based learning and adaptation"
    echo "  - Professional output without unnecessary formatting"
    echo ""
}

function main() {
    # Show help if requested
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        show_usage
        exit 0
    fi
    
    # Show banner
    show_banner
    
    # System checks
    check_requirements
    
    # Initialize AI
    initialize_ai
    
    # Run AI scan
    run_ai_scan "$TARGET" "$SCAN_TYPE"
    
    echo ""
    success "AI system operation completed"
    echo ""
}

# Handle interrupts gracefully
trap 'echo ""; warning "AI scan interrupted by user"; exit 1' INT

# Run main function
main "$@"