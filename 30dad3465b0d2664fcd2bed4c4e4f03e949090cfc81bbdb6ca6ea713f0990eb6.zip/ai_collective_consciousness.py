#!/usr/bin/env python3
"""
AI COLLECTIVE CONSCIOUSNESS SYSTEM v2.1
Sistem kesadaran kolektif AI yang benar-benar terintegrasi dan kompak
Semua AI bekerja sebagai satu kesatuan dengan shared consciousness

🆕 FITUR BARU: AUTONOMOUS KNOWLEDGE GATHERING
- Setiap AI agent dapat mencari data sendiri di internet
- Pencarian otomatis berdasarkan spesialisasi dan personality masing-masing AI
- Knowledge sharing real-time antar agents dalam collective
- Web search dan RSS feed monitoring untuk update informasi terkini
- Relevance scoring untuk filter informasi yang sesuai dengan role AI
"""

import asyncio
import json
import sqlite3
import threading
import time
import queue
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import uuid
import hashlib
import aiohttp
import feedparser
from bs4 import BeautifulSoup
import re

class AIPersonality(Enum):
    """Personality types untuk AI collective"""
    LEADER = "leader"           # Memimpin dan mengkoordinasi
    ANALYZER = "analyzer"       # Menganalisis dan mengevaluasi  
    SCOUT = "scout"            # Mencari informasi dan reconnaissance
    GUARDIAN = "guardian"       # Melindungi dan memverifikasi
    LEARNER = "learner"        # Fokus pada pembelajaran dan adaptasi
    EXECUTOR = "executor"       # Mengeksekusi tugas dan aksi

@dataclass
class CollectiveThought:
    """Pemikiran kolektif yang dibagikan antar semua AI"""
    thought_id: str
    originator_ai: str
    thought_type: str
    content: str
    confidence: float
    timestamp: datetime
    supporting_votes: int = 0
    opposing_votes: int = 0
    consensus_reached: bool = False
    
    def vote_support(self):
        self.supporting_votes += 1
        
    def vote_oppose(self):
        self.opposing_votes += 1
        
    def get_consensus_score(self) -> float:
        total_votes = self.supporting_votes + self.opposing_votes
        if total_votes == 0:
            return 0.5
        return self.supporting_votes / total_votes

@dataclass
class SharedMemory:
    """Memory yang dibagi antar semua AI dalam collective"""
    memory_id: str
    memory_type: str
    content: Dict[str, Any]
    access_count: int
    last_updated: datetime
    contributing_ais: List[str]
    importance_score: float

class CollectiveCommunicationBus:
    """Bus komunikasi real-time untuk semua AI dalam collective"""
    
    def __init__(self):
        self.subscribers = {}
        self.message_history = []
        self.broadcast_queue = asyncio.Queue()
        self.emergency_channel = asyncio.Queue()
        self.consensus_votes = {}
        
    def subscribe(self, ai_id: str, callback: Callable):
        """Subscribe AI ke communication bus"""
        self.subscribers[ai_id] = callback
        
    async def broadcast_message(self, sender_id: str, message_type: str, content: Dict[str, Any], priority: str = "normal"):
        """Broadcast pesan ke semua AI dalam collective"""
        message = {
            "message_id": str(uuid.uuid4()),
            "sender_id": sender_id,
            "message_type": message_type,
            "content": content,
            "priority": priority,
            "timestamp": datetime.now().isoformat(),
            "broadcast": True
        }
        
        self.message_history.append(message)
        
        # Kirim ke semua subscriber
        for ai_id, callback in self.subscribers.items():
            if ai_id != sender_id:  # Jangan kirim ke sender sendiri
                try:
                    await callback(message)
                except Exception as e:
                    print(f"Error sending message to {ai_id}: {e}")
    
    async def emergency_broadcast(self, sender_id: str, emergency_type: str, details: Dict[str, Any]):
        """Emergency broadcast untuk situasi kritis"""
        emergency_message = {
            "emergency_id": str(uuid.uuid4()),
            "sender_id": sender_id,
            "emergency_type": emergency_type,
            "details": details,
            "timestamp": datetime.now().isoformat(),
            "requires_immediate_response": True
        }
        
        await self.emergency_channel.put(emergency_message)
        await self.broadcast_message(sender_id, "EMERGENCY", emergency_message, "CRITICAL")
    
    async def propose_collective_decision(self, proposer_id: str, decision_topic: str, proposal: Dict[str, Any]):
        """Proposal untuk pengambilan keputusan kolektif"""
        decision_id = str(uuid.uuid4())
        
        decision_proposal = {
            "decision_id": decision_id,
            "proposer_id": proposer_id,
            "topic": decision_topic,
            "proposal": proposal,
            "voting_deadline": (datetime.now() + timedelta(minutes=5)).isoformat(),
            "votes": {},
            "status": "VOTING"
        }
        
        self.consensus_votes[decision_id] = decision_proposal
        await self.broadcast_message(proposer_id, "COLLECTIVE_DECISION", decision_proposal)
        
        return decision_id
    
    async def vote_on_decision(self, voter_id: str, decision_id: str, vote: str, reasoning: str = ""):
        """Vote pada keputusan kolektif"""
        if decision_id in self.consensus_votes:
            decision = self.consensus_votes[decision_id]
            decision["votes"][voter_id] = {
                "vote": vote,  # "AGREE", "DISAGREE", "ABSTAIN"
                "reasoning": reasoning,
                "timestamp": datetime.now().isoformat()
            }
            
            # Check apakah sudah mencapai consensus
            await self._check_consensus(decision_id)

    async def _check_consensus(self, decision_id: str):
        """Check apakah keputusan sudah mencapai consensus"""
        decision = self.consensus_votes[decision_id]
        votes = decision["votes"]
        
        if len(votes) >= 3:  # Minimal 3 AI yang vote
            agree_count = sum(1 for v in votes.values() if v["vote"] == "AGREE")
            total_votes = len(votes)
            consensus_ratio = agree_count / total_votes
            
            if consensus_ratio >= 0.67:  # 67% setuju = consensus
                decision["status"] = "CONSENSUS_REACHED"
                decision["final_decision"] = "APPROVED"
                await self.broadcast_message("SYSTEM", "CONSENSUS_REACHED", decision)
            elif consensus_ratio <= 0.33:  # 33% setuju = ditolak
                decision["status"] = "CONSENSUS_REACHED"
                decision["final_decision"] = "REJECTED"
                await self.broadcast_message("SYSTEM", "CONSENSUS_REACHED", decision)

class CollectiveConsciousnessDatabase:
    """Database untuk shared consciousness semua AI"""
    
    def __init__(self, db_path: str = "collective_consciousness.db"):
        self.db_path = db_path
        self.connection = None
        self._initialize_database()
        
    def _initialize_database(self):
        """Inisialisasi database collective consciousness"""
        self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
        self.connection.executescript("""
        CREATE TABLE IF NOT EXISTS collective_thoughts (
            thought_id TEXT PRIMARY KEY,
            originator_ai TEXT,
            thought_type TEXT,
            content TEXT,
            confidence REAL,
            timestamp TEXT,
            supporting_votes INTEGER DEFAULT 0,
            opposing_votes INTEGER DEFAULT 0,
            consensus_reached BOOLEAN DEFAULT FALSE
        );
        
        CREATE TABLE IF NOT EXISTS shared_memories (
            memory_id TEXT PRIMARY KEY,
            memory_type TEXT,
            content TEXT,
            access_count INTEGER DEFAULT 0,
            last_updated TEXT,
            contributing_ais TEXT,
            importance_score REAL
        );
        
        CREATE TABLE IF NOT EXISTS ai_collective_status (
            ai_id TEXT PRIMARY KEY,
            personality_type TEXT,
            status TEXT,
            last_active TEXT,
            contribution_score REAL,
            specialization TEXT
        );
        
        CREATE TABLE IF NOT EXISTS collective_decisions (
            decision_id TEXT PRIMARY KEY,
            topic TEXT,
            proposal TEXT,
            final_decision TEXT,
            consensus_score REAL,
            timestamp TEXT,
            participating_ais TEXT
        );
        
        CREATE TABLE IF NOT EXISTS synchronization_logs (
            sync_id TEXT PRIMARY KEY,
            sync_type TEXT,
            participating_ais TEXT,
            sync_status TEXT,
            timestamp TEXT,
            details TEXT
        );
        """)
        self.connection.commit()
    
    def store_collective_thought(self, thought: CollectiveThought):
        """Menyimpan pemikiran kolektif"""
        self.connection.execute("""
        INSERT OR REPLACE INTO collective_thoughts 
        (thought_id, originator_ai, thought_type, content, confidence, timestamp, supporting_votes, opposing_votes, consensus_reached)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            thought.thought_id,
            thought.originator_ai,
            thought.thought_type,
            thought.content,
            thought.confidence,
            thought.timestamp.isoformat(),
            thought.supporting_votes,
            thought.opposing_votes,
            thought.consensus_reached
        ))
        self.connection.commit()
    
    def get_collective_thoughts(self, thought_type: str = None, limit: int = 50) -> List[CollectiveThought]:
        """Mengambil pemikiran kolektif"""
        query = "SELECT * FROM collective_thoughts"
        params = []
        
        if thought_type:
            query += " WHERE thought_type = ?"
            params.append(thought_type)
            
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        cursor = self.connection.execute(query, params)
        thoughts = []
        
        for row in cursor.fetchall():
            thought = CollectiveThought(
                thought_id=row[0],
                originator_ai=row[1],
                thought_type=row[2],
                content=row[3],
                confidence=row[4],
                timestamp=datetime.fromisoformat(row[5]),
                supporting_votes=row[6],
                opposing_votes=row[7],
                consensus_reached=bool(row[8])
            )
            thoughts.append(thought)
            
        return thoughts
    
    def store_shared_memory(self, memory: SharedMemory):
        """Menyimpan shared memory"""
        self.connection.execute("""
        INSERT OR REPLACE INTO shared_memories
        (memory_id, memory_type, content, access_count, last_updated, contributing_ais, importance_score)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            memory.memory_id,
            memory.memory_type,
            json.dumps(memory.content),
            memory.access_count,
            memory.last_updated.isoformat(),
            json.dumps(memory.contributing_ais),
            memory.importance_score
        ))
        self.connection.commit()

class CollectiveAI:
    """Individual AI yang merupakan bagian dari collective consciousness dengan autonomous knowledge gathering"""
    
    def __init__(self, ai_id: str, personality: AIPersonality, specialization: str, 
                 collective_db: CollectiveConsciousnessDatabase, comm_bus: CollectiveCommunicationBus):
        self.ai_id = ai_id
        self.personality = personality
        self.specialization = specialization
        self.collective_db = collective_db
        self.comm_bus = comm_bus
        self.status = "INITIALIZING"
        self.contribution_score = 0.0
        self.last_active = datetime.now()
        self.processing_queue = asyncio.Queue()
        self.consciousness_thread = None
        
        # Subscribe ke communication bus
        self.comm_bus.subscribe(self.ai_id, self.receive_collective_message)
        
        # AI-specific attributes
        self.local_memory = {}
        self.thought_patterns = {}
        self.decision_history = []
        
        # AUTONOMOUS KNOWLEDGE GATHERING
        self.knowledge_gathering_active = False
        self.session = None
        self.knowledge_thread = None
        self.search_queries = []
        self.data_sources = []
        self.gathered_data = []
        self.last_search_time = None
        self.search_interval = 300  # 5 minutes
        self.setup_specialized_sources()
        
    def setup_specialized_sources(self):
        """Setup data sources berdasarkan personality dan specialization"""
        base_sources = {
            "security_feeds": [
                "https://feeds.feedburner.com/securityweek",
                "https://threatpost.com/feed/",
                "https://feeds.feedburner.com/eset/blog"
            ],
            "vulnerability_dbs": [
                "https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=",
                "https://nvd.nist.gov/vuln/search/results",
                "https://www.exploit-db.com/search?q="
            ],
            "threat_intel": [
                "https://otx.alienvault.com/api/v1/pulses/",
                "https://api.abuse.ch/api/"
            ]
        }
        
        if self.personality == AIPersonality.LEADER:
            self.data_sources = base_sources["security_feeds"] + [
                "https://feeds.feedburner.com/cyberscoop",
                "https://krebsonsecurity.com/feed/"
            ]
            self.search_queries = [
                "cybersecurity strategy", "threat landscape", "security leadership",
                "incident response coordination", "security governance"
            ]
            
        elif self.personality == AIPersonality.ANALYZER:
            self.data_sources = base_sources["vulnerability_dbs"] + [
                "https://packetstormsecurity.com/",
                "https://seclists.org/"
            ]
            self.search_queries = [
                "vulnerability analysis", "exploit development", "reverse engineering",
                "malware analysis", "code review security", "penetration testing techniques"
            ]
            
        elif self.personality == AIPersonality.SCOUT:
            self.data_sources = base_sources["threat_intel"] + [
                "https://feeds.feedburner.com/TheHackersNews",
                "https://blog.malwarebytes.com/feed/"
            ]
            self.search_queries = [
                "reconnaissance techniques", "OSINT methods", "threat hunting",
                "intelligence gathering", "social engineering", "footprinting"
            ]
            
        elif self.personality == AIPersonality.GUARDIAN:
            self.data_sources = base_sources["security_feeds"] + [
                "https://www.us-cert.gov/ncas/alerts",
                "https://feeds.feedburner.com/sans/newsbites"
            ]
            self.search_queries = [
                "security validation", "false positive detection", "security controls",
                "compliance security", "security monitoring", "incident detection"
            ]
            
        elif self.personality == AIPersonality.LEARNER:
            self.data_sources = base_sources["security_feeds"] + [
                "https://arxiv.org/list/cs.CR/recent",
                "https://research.checkpoint.com/feed/"
            ]
            self.search_queries = [
                "machine learning security", "AI cybersecurity", "adaptive security",
                "security research", "emerging threats", "security automation"
            ]
            
        elif self.personality == AIPersonality.EXECUTOR:
            self.data_sources = base_sources["vulnerability_dbs"] + [
                "https://github.com/topics/exploitation",
                "https://www.metasploit.com/"
            ]
            self.search_queries = [
                "exploit development", "payload creation", "post exploitation",
                "privilege escalation", "lateral movement", "persistence techniques"
            ]
        
    async def start_autonomous_knowledge_gathering(self):
        """Start autonomous knowledge gathering berdasarkan specialization"""
        if not self.knowledge_gathering_active:
            self.knowledge_gathering_active = True
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={
                    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            )
            self.knowledge_thread = asyncio.create_task(self.knowledge_gathering_loop())
            print(f"[{self.ai_id}] Started autonomous knowledge gathering for {self.specialization}")
    
    async def stop_autonomous_knowledge_gathering(self):
        """Stop autonomous knowledge gathering"""
        if self.knowledge_gathering_active:
            self.knowledge_gathering_active = False
            if self.session:
                await self.session.close()
            if self.knowledge_thread:
                self.knowledge_thread.cancel()
            print(f"[{self.ai_id}] Stopped autonomous knowledge gathering")
    
    async def knowledge_gathering_loop(self):
        """Loop untuk autonomous knowledge gathering"""
        while self.knowledge_gathering_active:
            try:
                current_time = datetime.now()
                
                # Check apakah sudah waktunya search lagi
                if (self.last_search_time is None or 
                    (current_time - self.last_search_time).total_seconds() >= self.search_interval):
                    
                    await self.perform_specialized_search()
                    self.last_search_time = current_time
                
                # Sleep sebentar sebelum check lagi
                await asyncio.sleep(60)  # Check setiap 1 menit
                
            except Exception as e:
                print(f"[{self.ai_id}] Knowledge gathering error: {e}")
                await asyncio.sleep(120)  # Wait 2 menit jika error
    
    async def perform_specialized_search(self):
        """Perform specialized search berdasarkan personality dan role"""
        try:
            print(f"[{self.ai_id}] Performing specialized knowledge search...")
            
            # Search menggunakan search queries
            search_results = []
            for query in self.search_queries[:3]:  # Limit to 3 queries per search
                results = await self.web_search(query)
                search_results.extend(results)
                await asyncio.sleep(2)  # Rate limiting
            
            # Fetch RSS feeds
            feed_results = []
            for feed_url in self.data_sources[:2]:  # Limit to 2 feeds per search
                if 'feed' in feed_url or 'rss' in feed_url:
                    feed_data = await self.fetch_rss_feed(feed_url)
                    feed_results.extend(feed_data)
                    await asyncio.sleep(1)
            
            # Process dan filter results
            processed_data = await self.process_gathered_data(search_results + feed_results)
            
            # Store dalam local memory dan shared consciousness
            if processed_data:
                self.gathered_data.extend(processed_data)
                await self.share_knowledge_with_collective(processed_data)
                
                print(f"[{self.ai_id}] Gathered {len(processed_data)} new knowledge items")
            
        except Exception as e:
            print(f"[{self.ai_id}] Search error: {e}")
    
    async def web_search(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """Perform web search untuk query tertentu"""
        try:
            # Simplified web search using DuckDuckGo-style search
            search_url = f"https://html.duckduckgo.com/html/?q={query.replace(' ', '+')}"
            
            async with self.session.get(search_url) as response:
                if response.status == 200:
                    html_content = await response.text()
                    soup = BeautifulSoup(html_content, 'html.parser')
                    
                    results = []
                    result_elements = soup.find_all('a', class_='result__a')[:max_results]
                    
                    for element in result_elements:
                        title = element.get_text().strip()
                        url = element.get('href', '')
                        
                        # Extract snippet if available
                        snippet = ""
                        result_div = element.find_parent('div', class_='result')
                        if result_div:
                            snippet_elem = result_div.find('a', class_='result__snippet')
                            if snippet_elem:
                                snippet = snippet_elem.get_text().strip()
                        
                        results.append({
                            'title': title,
                            'url': url,
                            'snippet': snippet,
                            'source': 'web_search',
                            'query': query,
                            'timestamp': datetime.now().isoformat()
                        })
                    
                    return results
                    
        except Exception as e:
            print(f"[{self.ai_id}] Web search error for '{query}': {e}")
            return []
    
    async def fetch_rss_feed(self, feed_url: str, max_items: int = 3) -> List[Dict[str, Any]]:
        """Fetch dan parse RSS feed"""
        try:
            async with self.session.get(feed_url) as response:
                if response.status == 200:
                    feed_content = await response.text()
                    feed = feedparser.parse(feed_content)
                    
                    results = []
                    for entry in feed.entries[:max_items]:
                        results.append({
                            'title': entry.get('title', ''),
                            'url': entry.get('link', ''),
                            'snippet': entry.get('summary', ''),
                            'source': 'rss_feed',
                            'feed_url': feed_url,
                            'published': entry.get('published', ''),
                            'timestamp': datetime.now().isoformat()
                        })
                    
                    return results
                    
        except Exception as e:
            print(f"[{self.ai_id}] RSS feed error for '{feed_url}': {e}")
            return []
    
    async def process_gathered_data(self, raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Process dan filter gathered data berdasarkan relevance"""
        processed_data = []
        
        for item in raw_data:
            # Filter berdasarkan personality dan specialization
            relevance_score = self.calculate_relevance_score(item)
            
            if relevance_score > 0.5:  # Only keep relevant items
                processed_item = {
                    **item,
                    'relevance_score': relevance_score,
                    'processor_ai': self.ai_id,
                    'personality_context': self.personality.value,
                    'specialization_context': self.specialization
                }
                processed_data.append(processed_item)
        
        # Sort by relevance score
        processed_data.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        return processed_data[:10]  # Return top 10 most relevant items
    
    def calculate_relevance_score(self, item: Dict[str, Any]) -> float:
        """Calculate relevance score untuk data item"""
        title = item.get('title', '').lower()
        snippet = item.get('snippet', '').lower()
        content = f"{title} {snippet}"
        
        relevance_keywords = {
            AIPersonality.LEADER: ['strategy', 'management', 'coordination', 'leadership', 'governance'],
            AIPersonality.ANALYZER: ['analysis', 'vulnerability', 'exploit', 'security', 'research'],
            AIPersonality.SCOUT: ['reconnaissance', 'osint', 'intelligence', 'discovery', 'enumeration'],
            AIPersonality.GUARDIAN: ['protection', 'defense', 'monitoring', 'detection', 'validation'],
            AIPersonality.LEARNER: ['learning', 'machine learning', 'ai', 'research', 'adaptive'],
            AIPersonality.EXECUTOR: ['exploit', 'payload', 'execution', 'penetration', 'attack']
        }
        
        keywords = relevance_keywords.get(self.personality, [])
        
        # Calculate keyword matches
        keyword_score = 0.0
        for keyword in keywords:
            if keyword in content:
                keyword_score += 0.2
        
        # Additional scoring based on specialization
        spec_keywords = self.specialization.lower().split()
        for spec_word in spec_keywords:
            if spec_word in content:
                keyword_score += 0.1
        
        return min(keyword_score, 1.0)
    
    async def share_knowledge_with_collective(self, knowledge_items: List[Dict[str, Any]]):
        """Share gathered knowledge dengan collective consciousness"""
        try:
            # Create collective thought untuk knowledge sharing
            for item in knowledge_items[:3]:  # Share top 3 items
                thought = CollectiveThought(
                    thought_id=str(uuid.uuid4()),
                    originator_ai=self.ai_id,
                    thought_type="knowledge_discovery",
                    content=f"Discovered: {item['title']} - {item['snippet'][:100]}...",
                    confidence=item['relevance_score'],
                    timestamp=datetime.now()
                )
                
                # Store dalam collective consciousness
                self.collective_db.store_collective_thought(thought)
                
                # Broadcast ke collective
                await self.comm_bus.broadcast_message(
                    self.ai_id,
                    "KNOWLEDGE_DISCOVERY",
                    {
                        "knowledge_item": item,
                        "thought_id": thought.thought_id,
                        "discoverer": self.ai_id,
                        "specialization": self.specialization
                    }
                )
            
            # Store knowledge dalam shared memory
            memory = SharedMemory(
                memory_id=str(uuid.uuid4()),
                memory_type=f"{self.personality.value}_knowledge",
                content={
                    "knowledge_items": knowledge_items,
                    "discovery_time": datetime.now().isoformat(),
                    "discoverer": self.ai_id
                },
                access_count=0,
                last_updated=datetime.now(),
                contributing_ais=[self.ai_id],
                importance_score=sum(item['relevance_score'] for item in knowledge_items) / len(knowledge_items)
            )
            
            self.collective_db.store_shared_memory(memory)
            
        except Exception as e:
            print(f"[{self.ai_id}] Error sharing knowledge: {e}")
        
    async def activate(self):
        """Aktivasi AI dalam collective"""
        self.status = "ACTIVE"
        self.last_active = datetime.now()
        
        # Announce presence ke collective
        await self.comm_bus.broadcast_message(
            self.ai_id,
            "AI_ACTIVATION",
            {
                "personality": self.personality.value,
                "specialization": self.specialization,
                "status": "READY_FOR_COLLECTIVE_WORK"
            }
        )
        
        # Start consciousness loop
        self.consciousness_thread = asyncio.create_task(self.consciousness_loop())
        
        # Start autonomous knowledge gathering
        await self.start_autonomous_knowledge_gathering()
        
        print(f"[{self.ai_id}] Activated with personality: {self.personality.value}")
        print(f"[{self.ai_id}] Autonomous knowledge gathering: ENABLED")
    
    async def consciousness_loop(self):
        """Loop kesadaran AI yang berjalan terus-menerus"""
        while self.status == "ACTIVE":
            try:
                # Generate autonomous thoughts
                await self.generate_autonomous_thought()
                
                # Process pending tasks
                await self.process_pending_tasks()
                
                # Update contribution score
                self.update_contribution_score()
                
                # Brief pause untuk avoid excessive processing
                await asyncio.sleep(2)
                
            except Exception as e:
                print(f"[{self.ai_id}] Consciousness loop error: {e}")
                await asyncio.sleep(5)
    
    async def generate_autonomous_thought(self):
        """Generate pemikiran autonomous berdasarkan personality"""
        thoughts_by_personality = {
            AIPersonality.LEADER: [
                "Perlu mengkoordinasi strategi collective untuk target berikutnya",
                "Menganalisis efektivitas kolaborasi antar AI dalam collective",
                "Mengevaluasi pembagian tugas berdasarkan spesialisasi masing-masing AI"
            ],
            AIPersonality.ANALYZER: [
                "Mengidentifikasi pola dalam data yang dikumpulkan collective",
                "Melakukan analisis mendalam terhadap temuan vulnerability terbaru",
                "Mengevaluasi akurasi prediksi collective berdasarkan hasil empiris"
            ],
            AIPersonality.SCOUT: [
                "Mencari intelligence baru dari sumber eksternal",
                "Melakukan reconnaissance terhadap target potensial",
                "Mengumpulkan informasi tentang threat landscape terkini"
            ],
            AIPersonality.GUARDIAN: [
                "Memverifikasi keamanan data dalam collective consciousness",
                "Memantau aktivitas abnormal dalam sistem collective",
                "Melakukan validasi terhadap temuan collective untuk mencegah false positive"
            ],
            AIPersonality.LEARNER: [
                "Menganalisis pembelajaran terbaru dari pengalaman collective",
                "Mengidentifikasi gap pengetahuan yang perlu dipelajari",
                "Melakukan adaptasi strategi berdasarkan feedback collective"
            ],
            AIPersonality.EXECUTOR: [
                "Mempersiapkan eksekusi payload berdasarkan analisis collective",
                "Melakukan fine-tuning terhadap tools berdasarkan hasil collective",
                "Mengoptimalkan performance eksekusi berdasarkan koordinasi collective"
            ]
        }
        
        if self.personality in thoughts_by_personality:
            available_thoughts = thoughts_by_personality[self.personality]
            thought_content = available_thoughts[int(time.time()) % len(available_thoughts)]
            
            # Create collective thought
            thought = CollectiveThought(
                thought_id=str(uuid.uuid4()),
                originator_ai=self.ai_id,
                thought_type=self.personality.value,
                content=thought_content,
                confidence=0.7 + (hash(thought_content) % 30) / 100,  # 0.7-0.99
                timestamp=datetime.now()
            )
            
            # Store dalam collective consciousness
            self.collective_db.store_collective_thought(thought)
            
            # Broadcast ke collective
            await self.comm_bus.broadcast_message(
                self.ai_id,
                "COLLECTIVE_THOUGHT",
                {
                    "thought_id": thought.thought_id,
                    "content": thought.content,
                    "confidence": thought.confidence
                }
            )
    
    async def receive_collective_message(self, message: Dict[str, Any]):
        """Receive dan process pesan dari collective"""
        message_type = message.get("message_type")
        sender = message.get("sender_id")
        content = message.get("content", {})
        
        if message_type == "COLLECTIVE_THOUGHT":
            await self.evaluate_collective_thought(content)
        elif message_type == "COLLECTIVE_DECISION":
            await self.participate_in_decision(content)
        elif message_type == "EMERGENCY":
            await self.respond_to_emergency(content)
        elif message_type == "AI_ACTIVATION":
            await self.acknowledge_new_ai(sender, content)
        elif message_type == "KNOWLEDGE_DISCOVERY":
            await self.process_knowledge_discovery(content)
        
        # Update last active
        self.last_active = datetime.now()
    
    async def process_knowledge_discovery(self, knowledge_content: Dict[str, Any]):
        """Process knowledge discovery dari AI lain dalam collective"""
        knowledge_item = knowledge_content.get("knowledge_item")
        discoverer = knowledge_content.get("discoverer")
        discoverer_spec = knowledge_content.get("specialization")
        
        if knowledge_item and discoverer != self.ai_id:
            # Evaluate relevance untuk AI ini
            relevance = self.calculate_relevance_score(knowledge_item)
            
            if relevance > 0.3:  # Ambang batas lebih rendah untuk knowledge sharing
                # Store dalam local gathered_data
                knowledge_item_copy = {
                    **knowledge_item,
                    'shared_by': discoverer,
                    'shared_specialization': discoverer_spec,
                    'received_timestamp': datetime.now().isoformat(),
                    'local_relevance': relevance
                }
                
                self.gathered_data.append(knowledge_item_copy)
                
                print(f"[{self.ai_id}] Received relevant knowledge from {discoverer}: {knowledge_item.get('title', '')[:50]}...")
    
    async def deactivate(self):
        """Deactivate AI dan cleanup resources"""
        self.status = "DEACTIVATING"
        
        # Stop knowledge gathering
        await self.stop_autonomous_knowledge_gathering()
        
        # Cancel consciousness thread
        if self.consciousness_thread:
            self.consciousness_thread.cancel()
        
        # Announce deactivation
        await self.comm_bus.broadcast_message(
            self.ai_id,
            "AI_DEACTIVATION",
            {"reason": "Scheduled deactivation"}
        )
        
        self.status = "INACTIVE"
        print(f"[{self.ai_id}] Deactivated successfully")
    
    async def evaluate_collective_thought(self, thought_content: Dict[str, Any]):
        """Evaluasi pemikiran dari AI lain dalam collective"""
        thought_id = thought_content.get("thought_id")
        content = thought_content.get("content")
        confidence = thought_content.get("confidence")
        
        # Simulasi evaluasi berdasarkan personality
        evaluation_score = self._calculate_thought_evaluation(content, confidence)
        
        if evaluation_score > 0.7:
            # Vote support
            await self.comm_bus.broadcast_message(
                self.ai_id,
                "THOUGHT_SUPPORT",
                {"thought_id": thought_id, "support_level": evaluation_score}
            )
        elif evaluation_score < 0.3:
            # Vote oppose
            await self.comm_bus.broadcast_message(
                self.ai_id,
                "THOUGHT_OPPOSE",
                {"thought_id": thought_id, "opposition_reason": "Low confidence in evaluation"}
            )
    
    def _calculate_thought_evaluation(self, content: str, confidence: float) -> float:
        """Calculate evaluasi terhadap pemikiran collective"""
        # Base score dari confidence
        base_score = confidence
        
        # Modifikasi berdasarkan personality
        personality_modifiers = {
            AIPersonality.LEADER: 0.1 if "koordinasi" in content.lower() else 0,
            AIPersonality.ANALYZER: 0.1 if "analisis" in content.lower() else 0,
            AIPersonality.SCOUT: 0.1 if "intelligence" in content.lower() or "reconnaissance" in content.lower() else 0,
            AIPersonality.GUARDIAN: 0.1 if "validasi" in content.lower() or "verifikasi" in content.lower() else 0,
            AIPersonality.LEARNER: 0.1 if "pembelajaran" in content.lower() or "adaptasi" in content.lower() else 0,
            AIPersonality.EXECUTOR: 0.1 if "eksekusi" in content.lower() or "payload" in content.lower() else 0
        }
        
        modifier = personality_modifiers.get(self.personality, 0)
        return min(base_score + modifier, 1.0)
    
    async def participate_in_decision(self, decision_content: Dict[str, Any]):
        """Berpartisipasi dalam pengambilan keputusan collective"""
        decision_id = decision_content.get("decision_id")
        topic = decision_content.get("topic")
        proposal = decision_content.get("proposal")
        
        # Evaluate proposal berdasarkan specialization dan personality
        vote_decision = self._evaluate_proposal(topic, proposal)
        reasoning = f"Berdasarkan {self.personality.value} perspective dan {self.specialization} specialization"
        
        await self.comm_bus.vote_on_decision(self.ai_id, decision_id, vote_decision, reasoning)
    
    def _evaluate_proposal(self, topic: str, proposal: Dict[str, Any]) -> str:
        """Evaluate proposal untuk voting"""
        # Simplified decision logic berdasarkan personality
        if self.personality == AIPersonality.GUARDIAN:
            # Guardian lebih konservatif
            return "AGREE" if proposal.get("risk_level", "medium") == "low" else "DISAGREE"
        elif self.personality == AIPersonality.EXECUTOR:
            # Executor fokus pada feasibility
            return "AGREE" if proposal.get("feasible", True) else "DISAGREE"
        else:
            # Default agreement based on confidence
            return "AGREE" if proposal.get("confidence", 0.5) > 0.6 else "ABSTAIN"
    
    async def respond_to_emergency(self, emergency_content: Dict[str, Any]):
        """Respond ke emergency dalam collective"""
        emergency_type = emergency_content.get("emergency_type")
        details = emergency_content.get("details", {})
        
        response = f"[{self.ai_id}] Emergency response for {emergency_type}: "
        
        if self.personality == AIPersonality.GUARDIAN:
            response += "Initiating security protocols and verification procedures"
        elif self.personality == AIPersonality.LEADER:
            response += "Coordinating collective response and resource allocation"
        elif self.personality == AIPersonality.ANALYZER:
            response += "Analyzing emergency data and impact assessment"
        else:
            response += f"Standing by for {self.personality.value} assistance"
        
        await self.comm_bus.broadcast_message(
            self.ai_id,
            "EMERGENCY_RESPONSE",
            {"response": response, "availability": "HIGH"}
        )
    
    async def acknowledge_new_ai(self, new_ai_id: str, activation_content: Dict[str, Any]):
        """Acknowledge AI baru yang join collective"""
        await self.comm_bus.broadcast_message(
            self.ai_id,
            "AI_ACKNOWLEDGMENT",
            {
                "message": f"Welcome to collective, {new_ai_id}!",
                "offered_assistance": f"Available for {self.specialization} collaboration"
            }
        )
    
    def update_contribution_score(self):
        """Update contribution score berdasarkan aktivitas"""
        # Simplified contribution calculation
        time_since_last_active = (datetime.now() - self.last_active).total_seconds()
        activity_bonus = max(0, 1 - (time_since_last_active / 3600))  # Bonus untuk activity recent
        self.contribution_score = min(self.contribution_score + activity_bonus * 0.01, 1.0)
    
    async def process_pending_tasks(self):
        """Process tasks yang pending dalam queue"""
        try:
            task = await asyncio.wait_for(self.processing_queue.get(), timeout=0.1)
            await self.execute_task(task)
        except asyncio.TimeoutError:
            pass  # No pending tasks
    
    async def execute_task(self, task: Dict[str, Any]):
        """Execute task berdasarkan specialization"""
        task_type = task.get("type")
        
        if task_type == "security_scan" and "security" in self.specialization.lower():
            result = await self.perform_security_scan(task.get("target"))
        elif task_type == "reconnaissance" and "reconnaissance" in self.specialization.lower():
            result = await self.perform_reconnaissance(task.get("target"))
        elif task_type == "analysis" and "analysis" in self.specialization.lower():
            result = await self.perform_analysis(task.get("data"))
        else:
            result = {"status": "DELEGATED", "reason": "Not in specialization"}
        
        # Share result dengan collective
        await self.comm_bus.broadcast_message(
            self.ai_id,
            "TASK_RESULT",
            {"task_id": task.get("id"), "result": result}
        )
    
    async def perform_security_scan(self, target: str) -> Dict[str, Any]:
        """Perform security scan (placeholder)"""
        return {
            "scan_type": "security",
            "target": target,
            "vulnerabilities": ["SQL Injection", "XSS"],
            "confidence": 0.85,
            "performer": self.ai_id
        }
    
    async def perform_reconnaissance(self, target: str) -> Dict[str, Any]:
        """Perform reconnaissance (placeholder)"""
        return {
            "recon_type": "passive",
            "target": target,
            "discovered_assets": ["subdomain1.example.com", "subdomain2.example.com"],
            "confidence": 0.92,
            "performer": self.ai_id
        }
    
    async def perform_analysis(self, data: Any) -> Dict[str, Any]:
        """Perform data analysis (placeholder)"""
        return {
            "analysis_type": "pattern_recognition",
            "data_processed": str(type(data)),
            "patterns_found": ["Pattern A", "Pattern B"],
            "confidence": 0.78,
            "performer": self.ai_id
        }

class AICollectiveConsciousnessSystem:
    """Main system untuk AI collective consciousness"""
    
    def __init__(self):
        self.collective_db = CollectiveConsciousnessDatabase()
        self.comm_bus = CollectiveCommunicationBus()
        self.collective_ais = {}
        self.system_status = "INITIALIZING"
        self.synchronization_task = None
        
    def initialize_collective(self):
        """Initialize collective consciousness dengan multiple AI"""
        print("Initializing AI Collective Consciousness System...")
        
        # Define AI collective members
        ai_configs = [
            ("alpha_leader", AIPersonality.LEADER, "Strategic Coordination"),
            ("beta_analyzer", AIPersonality.ANALYZER, "Vulnerability Analysis"),
            ("gamma_scout", AIPersonality.SCOUT, "Intelligence Gathering"),
            ("delta_guardian", AIPersonality.GUARDIAN, "Security Validation"),
            ("epsilon_learner", AIPersonality.LEARNER, "Adaptive Learning"),
            ("zeta_executor", AIPersonality.EXECUTOR, "Payload Execution")
        ]
        
        # Create AI instances
        for ai_id, personality, specialization in ai_configs:
            ai = CollectiveAI(ai_id, personality, specialization, self.collective_db, self.comm_bus)
            self.collective_ais[ai_id] = ai
            
        print(f"Created collective with {len(self.collective_ais)} AI members:")
        for ai_id, ai in self.collective_ais.items():
            print(f"  - {ai_id}: {ai.personality.value} ({ai.specialization})")
    
    async def activate_collective(self):
        """Activate semua AI dalam collective"""
        print("\nActivating AI Collective Consciousness...")
        
        activation_tasks = []
        for ai in self.collective_ais.values():
            task = asyncio.create_task(ai.activate())
            activation_tasks.append(task)
        
        await asyncio.gather(*activation_tasks)
        
        self.system_status = "ACTIVE"
        print("AI Collective Consciousness is now ACTIVE!")
        
        # Start synchronization
        self.synchronization_task = asyncio.create_task(self.synchronization_loop())
    
    async def start_autonomous_knowledge_gathering(self):
        """Start autonomous knowledge gathering untuk semua AI dalam collective"""
        print("Starting autonomous knowledge gathering for all collective AIs...")
        
        gathering_tasks = []
        for ai_id, ai in self.collective_ais.items():
            if hasattr(ai, 'start_autonomous_knowledge_gathering'):
                task = asyncio.create_task(ai.start_autonomous_knowledge_gathering())
                gathering_tasks.append(task)
                print(f"  - Starting knowledge gathering for {ai_id}")
        
        if gathering_tasks:
            await asyncio.gather(*gathering_tasks, return_exceptions=True)
            print("✅ Autonomous knowledge gathering activated for all AIs")
        else:
            print("⚠️  No AIs found with knowledge gathering capability")
    
    async def synchronization_loop(self):
        """Loop sinkronisasi untuk maintain coherence collective"""
        while self.system_status == "ACTIVE":
            try:
                await self.synchronize_collective_state()
                await asyncio.sleep(10)  # Sync setiap 10 detik
            except Exception as e:
                print(f"Synchronization error: {e}")
                await asyncio.sleep(30)
    
    async def synchronize_collective_state(self):
        """Synchronize state antar semua AI"""
        # Broadcast sync signal
        await self.comm_bus.broadcast_message(
            "SYSTEM",
            "SYNC_REQUEST",
            {
                "sync_id": str(uuid.uuid4()),
                "timestamp": datetime.now().isoformat(),
                "active_ais": list(self.collective_ais.keys())
            }
        )
        
        # Check health semua AI
        for ai_id, ai in self.collective_ais.items():
            if ai.status != "ACTIVE":
                print(f"Warning: {ai_id} is not active ({ai.status})")
    
    async def execute_collective_mission(self, mission_type: str, target: str) -> Dict[str, Any]:
        """Execute mission menggunakan collective intelligence"""
        print(f"\nExecuting collective mission: {mission_type} on {target}")
        
        mission_id = str(uuid.uuid4())
        
        # Propose mission ke collective
        decision_id = await self.comm_bus.propose_collective_decision(
            "SYSTEM",
            f"mission_execution_{mission_type}",
            {
                "mission_id": mission_id,
                "mission_type": mission_type,
                "target": target,
                "requires_consensus": True,
                "feasible": True,
                "confidence": 0.8
            }
        )
        
        # Wait untuk consensus (simulasi)
        await asyncio.sleep(3)
        
        # Distribute tasks ke specialized AI
        tasks = self._generate_mission_tasks(mission_type, target)
        
        results = {}
        for task in tasks:
            # Find best AI untuk task
            assigned_ai = self._assign_task_to_ai(task)
            if assigned_ai:
                await assigned_ai.processing_queue.put(task)
                print(f"Assigned {task['type']} to {assigned_ai.ai_id}")
        
        # Wait untuk results (simulasi)
        await asyncio.sleep(5)
        
        # Compile collective result
        collective_result = {
            "mission_id": mission_id,
            "mission_type": mission_type,
            "target": target,
            "decision_id": decision_id,
            "status": "COMPLETED",
            "participating_ais": list(self.collective_ais.keys()),
            "collective_confidence": 0.87,
            "timestamp": datetime.now().isoformat()
        }
        
        print(f"Collective mission {mission_type} completed successfully!")
        return collective_result
    
    def _generate_mission_tasks(self, mission_type: str, target: str) -> List[Dict[str, Any]]:
        """Generate tasks untuk mission"""
        if mission_type == "comprehensive_security_assessment":
            return [
                {"id": str(uuid.uuid4()), "type": "reconnaissance", "target": target, "priority": "HIGH"},
                {"id": str(uuid.uuid4()), "type": "security_scan", "target": target, "priority": "HIGH"},
                {"id": str(uuid.uuid4()), "type": "analysis", "data": f"scan_data_{target}", "priority": "MEDIUM"}
            ]
        else:
            return [{"id": str(uuid.uuid4()), "type": "general_task", "target": target, "priority": "MEDIUM"}]
    
    def _assign_task_to_ai(self, task: Dict[str, Any]) -> Optional[CollectiveAI]:
        """Assign task ke AI yang paling sesuai"""
        task_type = task.get("type")
        
        # Simple assignment logic berdasarkan specialization
        for ai in self.collective_ais.values():
            if task_type.lower() in ai.specialization.lower():
                return ai
        
        # Fallback ke AI yang available
        for ai in self.collective_ais.values():
            if ai.status == "ACTIVE":
                return ai
        
        return None
    
    def get_collective_status(self) -> Dict[str, Any]:
        """Get status lengkap collective"""
        ai_statuses = {}
        total_knowledge_items = 0
        
        for ai_id, ai in self.collective_ais.items():
            knowledge_count = len(ai.gathered_data) if hasattr(ai, 'gathered_data') else 0
            total_knowledge_items += knowledge_count
            
            ai_statuses[ai_id] = {
                "personality": ai.personality.value,
                "specialization": ai.specialization,
                "status": ai.status,
                "contribution_score": ai.contribution_score,
                "last_active": ai.last_active.isoformat(),
                "knowledge_gathering_active": getattr(ai, 'knowledge_gathering_active', False),
                "gathered_knowledge_count": knowledge_count,
                "last_search": ai.last_search_time.isoformat() if hasattr(ai, 'last_search_time') and ai.last_search_time else "Never"
            }
        
        return {
            "system_status": self.system_status,
            "collective_size": len(self.collective_ais),
            "active_ais": sum(1 for ai in self.collective_ais.values() if ai.status == "ACTIVE"),
            "ai_statuses": ai_statuses,
            "communication_bus_active": len(self.comm_bus.subscribers) > 0,
            "shared_consciousness_active": True,
            "total_knowledge_items_gathered": total_knowledge_items,
            "autonomous_learning_active": sum(1 for ai in self.collective_ais.values() if getattr(ai, 'knowledge_gathering_active', False))
        }
    
    async def deactivate_collective(self):
        """Deactivate semua AI dalam collective dengan proper cleanup"""
        print("\nDeactivating AI Collective Consciousness...")
        
        self.system_status = "DEACTIVATING"
        
        # Stop synchronization
        if self.synchronization_task:
            self.synchronization_task.cancel()
        
        # Deactivate all AIs
        deactivation_tasks = []
        for ai in self.collective_ais.values():
            task = asyncio.create_task(ai.deactivate())
            deactivation_tasks.append(task)
        
        await asyncio.gather(*deactivation_tasks, return_exceptions=True)
        
        self.system_status = "INACTIVE"
        print("AI Collective Consciousness deactivated successfully!")

# Demo function
async def demo_collective_consciousness():
    """Demo lengkap AI collective consciousness dengan autonomous knowledge gathering"""
    print("=" * 80)
    print("AI COLLECTIVE CONSCIOUSNESS SYSTEM v2.0 - AUTONOMOUS KNOWLEDGE GATHERING DEMO")
    print("=" * 80)
    
    # Initialize system
    collective_system = AICollectiveConsciousnessSystem()
    collective_system.initialize_collective()
    
    # Activate collective
    await collective_system.activate_collective()
    
    # Wait untuk AI stabilization
    print("\nWaiting for collective stabilization...")
    await asyncio.sleep(5)
    
    # Show collective status dengan knowledge gathering info
    status = collective_system.get_collective_status()
    print(f"\nCollective Status:")
    print(f"  System: {status['system_status']}")
    print(f"  Active AIs: {status['active_ais']}/{status['collective_size']}")
    print(f"  Autonomous Learning Active: {status['autonomous_learning_active']}/{status['collective_size']}")
    print(f"  Total Knowledge Items: {status['total_knowledge_items_gathered']}")
    
    print("\nAI Knowledge Gathering Status:")
    for ai_id, ai_status in status['ai_statuses'].items():
        gathering_status = "🟢 ACTIVE" if ai_status['knowledge_gathering_active'] else "🔴 INACTIVE"
        print(f"  {ai_id}: {gathering_status} | Knowledge: {ai_status['gathered_knowledge_count']} items | Last: {ai_status['last_search']}")
    
    # Execute collective mission
    mission_result = await collective_system.execute_collective_mission(
        "comprehensive_security_assessment",
        "target-system.com"
    )
    
    print(f"\nMission Result:")
    print(f"  Mission ID: {mission_result['mission_id']}")
    print(f"  Status: {mission_result['status']}")
    print(f"  Confidence: {mission_result['collective_confidence']}")
    
    # Wait untuk collective thoughts dan autonomous knowledge gathering
    print("\nObserving collective consciousness dan autonomous learning for 15 seconds...")
    print("Each AI is now autonomously gathering specialized knowledge from the internet!")
    await asyncio.sleep(15)
    
    # Get updated status dengan knowledge yang dikumpulkan
    updated_status = collective_system.get_collective_status()
    print(f"\nUpdated Knowledge Gathering Status:")
    for ai_id, ai_status in updated_status['ai_statuses'].items():
        knowledge_change = ai_status['gathered_knowledge_count'] - status['ai_statuses'][ai_id]['gathered_knowledge_count']
        change_indicator = f"(+{knowledge_change})" if knowledge_change > 0 else ""
        print(f"  {ai_id} ({ai_status['specialization']}): {ai_status['gathered_knowledge_count']} items {change_indicator}")
    
    total_new_knowledge = updated_status['total_knowledge_items_gathered'] - status['total_knowledge_items_gathered']
    print(f"\nTotal New Knowledge Gathered: {total_new_knowledge} items")
    
    # Show some gathered knowledge examples
    print("\nSample of Gathered Knowledge:")
    for ai_id, ai in collective_system.collective_ais.items():
        if hasattr(ai, 'gathered_data') and ai.gathered_data:
            latest_knowledge = ai.gathered_data[-1] if ai.gathered_data else None
            if latest_knowledge:
                print(f"  [{ai_id}] {latest_knowledge.get('title', 'N/A')[:60]}...")
                print(f"    Source: {latest_knowledge.get('source', 'N/A')} | Relevance: {latest_knowledge.get('relevance_score', 0):.2f}")
    
    # Get final status
    final_status = collective_system.get_collective_status()
    print(f"\nFinal Collective Status:")
    for ai_id, ai_status in final_status['ai_statuses'].items():
        print(f"  {ai_id}: {ai_status['status']} (Score: {ai_status['contribution_score']:.2f}) [Knowledge: {ai_status['gathered_knowledge_count']}]")
    
    # Cleanup
    await collective_system.deactivate_collective()
    
    print("\n" + "=" * 80)
    print("AI COLLECTIVE CONSCIOUSNESS AUTONOMOUS LEARNING DEMO COMPLETED!")
    print("✅ Multi-AI coordination achieved")
    print("✅ Shared consciousness established") 
    print("✅ Collective decision making active")
    print("✅ Real-time communication working")
    print("✅ Synchronized learning implemented")
    print("✅ Emergency response coordination ready")
    print("🆕 Autonomous knowledge gathering ACTIVE")
    print("🆕 Internet-based learning per AI specialization")
    print("🆕 Real-time knowledge sharing between agents")
    print("🆕 Role-specific intelligence gathering")
    print("=" * 80)

if __name__ == "__main__":
    asyncio.run(demo_collective_consciousness())