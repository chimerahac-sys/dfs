#!/usr/bin/env python3
"""
SIMPLE LAUNCHER untuk Advanced AI Consciousness System
Launcher sederhana untuk menjalankan sistem AI tanpa kompleksitas
"""

import sys
import os
import subprocess
import time

def print_banner():
    """Print banner aplikasi"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    ADVANCED AI CONSCIOUSNESS SYSTEM                         ║
║                          - SIMPLE LAUNCHER -                                ║
║                                                                              ║
║  AI dengan pembelajaran adaptif dan consciousness dalam bahasa Indonesia    ║
║  • Vulnerability scanning dengan accuracy tinggi                            ║
║  • False positive detection yang akurat                                     ║
║  • Learning system yang benar-benar adaptif                                 ║
║                                                                              ║
║  Dikembangkan oleh: MiniMax Agent                                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")

def check_dependencies():
    """Check dependencies sederhana"""
    required = ['requests', 'beautifulsoup4', 'sklearn', 'numpy', 'nltk', 'psutil', 'yaml']
    missing = []
    
    for module in required:
        try:
            if module == 'beautifulsoup4':
                import bs4
            elif module == 'sklearn':
                import sklearn
            elif module == 'yaml':
                import yaml
            else:
                __import__(module)
        except ImportError:
            missing.append(module)
    
    if missing:
        print(f"❌ Missing dependencies: {', '.join(missing)}")
        print("Install with: pip install requests beautifulsoup4 scikit-learn numpy nltk psutil pyyaml")
        return False
    
    print("✅ All dependencies available")
    return True

def show_menu():
    """Show main menu"""
    print("""
PILIHAN MENU:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 🔍 Scanner Interaktif           - Mode interaktif untuk multiple scan
2. 🎯 Single Target Scan          - Scan satu target langsung
3. 🧪 Demo Sistem                 - Demonstrasi fitur AI consciousness
4. 🔬 Test Sistem                 - Test semua komponen sistem
5. 📋 Status Sistem               - Cek status dan pembelajaran AI
6. 📚 Bantuan                     - Panduan penggunaan
7. 🚪 Keluar                      - Exit aplikasi

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

def run_interactive_scanner():
    """Run interactive scanner"""
    print("Meluncurkan Scanner Interaktif...")
    try:
        subprocess.run([sys.executable, "intelligent_scanner.py"], check=True)
    except subprocess.CalledProcessError:
        print("❌ Error menjalankan scanner")
    except FileNotFoundError:
        print("❌ File intelligent_scanner.py tidak ditemukan")

def run_single_scan():
    """Run single scan"""
    target = input("Masukkan target (domain/IP): ").strip()
    if not target:
        print("❌ Target tidak boleh kosong")
        return
    
    print(f"Meluncurkan scan pada {target}...")
    try:
        subprocess.run([sys.executable, "intelligent_scanner.py", target], check=True)
    except subprocess.CalledProcessError:
        print("❌ Error menjalankan scanner")
    except FileNotFoundError:
        print("❌ File intelligent_scanner.py tidak ditemukan")

def run_demo():
    """Run system demo"""
    print("Meluncurkan Demo Sistem...")
    print("PILIH JENIS DEMO:")
    print("1. Demo Lengkap (semua fitur)")
    print("2. Demo Singkat (quick demo)")
    
    choice = input("Pilihan [1-2]: ").strip()
    
    try:
        if choice == "1":
            subprocess.run([sys.executable, "demo_ai_system.py"], check=True)
        elif choice == "2":
            subprocess.run([sys.executable, "demo_ai_system.py", "--quick"], check=True)
        else:
            print("❌ Pilihan tidak valid")
    except subprocess.CalledProcessError:
        print("❌ Error menjalankan demo")
    except FileNotFoundError:
        print("❌ File demo_ai_system.py tidak ditemukan")

def run_test():
    """Run system test"""
    print("Meluncurkan Test Sistem...")
    try:
        subprocess.run([sys.executable, "test_ai_system.py"], check=True)
    except subprocess.CalledProcessError:
        print("❌ Error menjalankan test")
    except FileNotFoundError:
        print("❌ File test_ai_system.py tidak ditemukan")

def check_system_status():
    """Check system status"""
    print("SYSTEM STATUS CHECK")
    print("=" * 50)
    
    # Check files
    files_to_check = [
        "advanced_ai_consciousness_system.py",
        "intelligent_scanner.py", 
        "demo_ai_system.py",
        "test_ai_system.py",
        "requirements.txt",
        "config.yaml"
    ]
    
    print("📁 File Check:")
    for file in files_to_check:
        if os.path.exists(file):
            size = os.path.getsize(file) / 1024  # KB
            print(f"  ✅ {file} ({size:.1f} KB)")
        else:
            print(f"  ❌ {file} - MISSING")
    
    # Check AI database
    print("\n🧠 AI Memory System:")
    if os.path.exists("ai_memory.db"):
        size = os.path.getsize("ai_memory.db") / 1024  # KB
        print(f"  ✅ ai_memory.db ({size:.1f} KB)")
        
        # Try to connect and check records
        try:
            import sqlite3
            conn = sqlite3.connect("ai_memory.db")
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM learning_memory")
            learning_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM vulnerability_knowledge")
            vuln_count = cursor.fetchone()[0]
            
            print(f"  📚 Learning entries: {learning_count}")
            print(f"  🔍 Vulnerability knowledge: {vuln_count}")
            
            conn.close()
        except Exception as e:
            print(f"  ⚠️  Database error: {e}")
    else:
        print("  📝 ai_memory.db - Akan dibuat saat pertama kali digunakan")
    
    # Check dependencies
    print("\n📦 Dependencies:")
    deps_ok = check_dependencies()
    
    print(f"\n🎯 SISTEM STATUS: {'READY' if deps_ok else 'NEEDS SETUP'}")

def show_help():
    """Show help"""
    print("""
PANDUAN PENGGUNAAN ADVANCED AI CONSCIOUSNESS SYSTEM
═══════════════════════════════════════════════════════════════

🔧 SETUP AWAL:
  pip install requests beautifulsoup4 scikit-learn numpy nltk psutil pyyaml

🚀 MENJALANKAN:
  1. Gunakan launcher ini: python3 run.py
  2. Langsung scanner: python3 intelligent_scanner.py
  3. Demo sistem: python3 demo_ai_system.py

🎯 CONTOH PENGGUNAAN:
  • Scanner interaktif untuk multiple target
  • Single scan: intelligent_scanner.py example.com
  • Demo fitur AI consciousness
  • Test semua komponen sistem

✨ FITUR UTAMA:
  • AI consciousness yang benar-benar learning
  • Vulnerability scanning dengan accuracy tinggi
  • False positive detection yang akurat
  • Laporan dalam bahasa Indonesia
  • Pembelajaran adaptif dari setiap scan

📋 FILE PENTING:
  • advanced_ai_consciousness_system.py - Core AI system
  • intelligent_scanner.py - Main scanner
  • demo_ai_system.py - Demo fitur
  • test_ai_system.py - Testing suite
  • config.yaml - Konfigurasi sistem
  • ai_memory.db - Database pembelajaran AI

🔍 TROUBLESHOOTING:
  • Missing dependencies: install dengan pip
  • Permission denied: jalankan dengan python3
  • Database error: hapus ai_memory.db untuk reset

📚 DOKUMENTASI LENGKAP:
  • README.md - Dokumentasi utama
  • QUICK_START.md - Panduan cepat
  • SYSTEM_UPGRADE_SUMMARY.md - Detail upgrade

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

def main():
    """Main function"""
    print_banner()
    
    # Check dependencies
    if not check_dependencies():
        print("\n⚠️  Beberapa dependencies hilang. Install dulu dengan:")
        print("pip install requests beautifulsoup4 scikit-learn numpy nltk psutil pyyaml")
        print("\nTekan Enter untuk lanjut atau Ctrl+C untuk keluar...")
        input()
    
    while True:
        show_menu()
        
        try:
            choice = input("Pilih menu [1-7]: ").strip()
            
            if choice == "1":
                run_interactive_scanner()
            elif choice == "2":
                run_single_scan()
            elif choice == "3":
                run_demo()
            elif choice == "4":
                run_test()
            elif choice == "5":
                check_system_status()
            elif choice == "6":
                show_help()
            elif choice == "7":
                print("👋 Terima kasih telah menggunakan Advanced AI Consciousness System!")
                break
            else:
                print("❌ Pilihan tidak valid. Pilih 1-7.")
            
            if choice in ["1", "2", "3", "4"]:
                print("\nTekan Enter untuk kembali ke menu...")
                input()
                
        except KeyboardInterrupt:
            print("\n\n👋 Keluar dari aplikasi...")
            break
        except Exception as e:
            print(f"❌ Error: {e}")
            print("Tekan Enter untuk lanjut...")
            input()

if __name__ == "__main__":
    main()